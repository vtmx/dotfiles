// VueDatapick
import DatePick from 'vue-date-pick';
import 'vue-date-pick/dist/vueDatePick.css';