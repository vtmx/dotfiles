<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Aguardando recebimento da licença',
      status: 'Em espera',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = 'Aguardando o fornecedor enviar a licença.';
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>