<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="licencas" class="uk-form-label required">Licenças</label>
        <v-select id="licencas" class="v-select" v-model="licenca" :options="options" :selectOnTab="true" @input="updateDetalhes">
          <div slot="no-options">Licença não encontrada</div>
        </v-select>
      </div>

      <div class="uk-width-1-2">
        <label for="maquina" class="uk-form-label required">Máquina</label>
        <input id="maquina" type="text" class="uk-input" required v-model="maquina" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="dados-ativacao" class="uk-form-label required">Dados de ativação</label>
        <input id="dados-ativacao" type="text" class="uk-input" required v-model="dadosAtivacao" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="solicitacao-recursos" class="uk-form-label required">Solicitação de recursos</label>
        <input id="solicitacao-recursos" type="text" class="uk-input" required v-model="solicitacaoRecursos" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="diretorio" class="uk-form-label required">Diretório</label>
        <input id="diretorio" type="text" class="uk-input" required v-model="diretorio" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="documentacao-tecnica" class="uk-form-label required">Documentação técnica</label>
        <input id="documentacao-tecnica" type="text" class="uk-input" required v-model="documentacaoTecnica" @input="updateDetalhes" />
      </div>
    </div> <!-- uk-grid -->

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import { softwares } from '~/pages/data/licencas';
import vSelect from 'vue-select';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
    vSelect,
  },
  data() {
    return {
      resumo: 'Informações',
      status: 'Em espera',
      detalhes: '',
      // ---
      licenca: 'Adobe Acrobat',
      options: softwares,
      maquina: '',
      dadosAtivacao: '',
      solicitacaoRecursos: '',
      diretorio: '',
      documentacaoTecnica: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.detalhes = this.licenca

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.$store.commit('updateDetalhes', this.detalhes);
  },
  methods: {
    updateDetalhes() {

      this.detalhes = this.licenca

      this.$store.commit('updateStatus', this.status);
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>
