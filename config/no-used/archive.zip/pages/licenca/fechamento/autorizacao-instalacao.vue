
<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="software" class="uk-form-label required">Software</label>
        <v-select id="software" class="v-select" v-model="software" :options="options" :selectOnTab="true" @input="updateDetalhes">
          <div slot="no-options">Software não encontrado.</div>
        </v-select>
      </div>

      <div class="uk-width-1-2 adobe-options dn">
        <label for="adobe-id" class="uk-form-label required">Tipo de licença</label>
        <select id="adobe-id" class="uk-select" v-model="adobeId" @change="updateDetalhes">
          <option>ADOBE ID</option>
          <option>FEDERATED ID</option>
        </select>
      </div>

      <div class="uk-width-1-2 so dn">
        <label for="so" class="uk-form-label required">Sistema operacional</label>
        <select id="so" class="uk-select" v-model="so" @change="updateDetalhes">
          <option>Windows</option>
          <option>Mac</option>
          <option>Linux</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="controle-ti" class="uk-form-label required">Controle TI</label>
        <input id="controle-ti" type="text" class="uk-input" required v-model="controleTi" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2 dados-ativacao">
        <label for="dados-ativacao" class="uk-form-label">Dados de ativação</label>
        <input id="dados-ativacao" class="uk-input" v-model="dadosAtivacao" @input="updateDetalhes">
      </div>

      <div class="uk-width-1-2 solicitacao-recursos">
        <label for="solicitacao-recursos" class="uk-form-label">Solicitação de recursos</label>
        <input id="solicitacao-recursos" class="uk-input" v-model="solicitacaoRecursos" @input="updateDetalhes">
      </div>

      <div class="uk-width-1-2 diretorio">
        <label for="diretorio" class="uk-form-label">Diretório</label>
        <input id="diretorio" type="text" class="uk-input" v-model="diretorio" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2 documentacao-tecnica">
        <label for="documentacao-tecnica" class="uk-form-label">Documentação técnica</label>
        <input id="documentacao-tecnica" type="text" class="uk-input" v-model="documentacaoTecnica" @input="updateDetalhes" />
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import vSelect from 'vue-select';
import LogButtons from '~/components/log-buttons.vue';

let softwares = [
  'Adobe Acrobat DC',
  'Adobe After Effects',
  'Teste'
]

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
    vSelect,
  },
  data() {
    return {
      resumo: 'Autorização de instalação',
      status: 'Encerrado totalmente',
      detalhes: '',
      // ---
      controleTi: '',
      software: '',
      options: softwares,
      adobeId: 'ADOBE ID',
      so: 'Windows',
      dadosAtivacao: '',
      solicitacaoRecursos: '',
      diretorio: '',
      documentacaoTecnica: '',
    };
  },
  mounted() {
    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },

  methods: {
    addAdobeOptions() {
      // show
      document.querySelector('.adobe-options').classList.remove('dn');
      document.querySelector('.so').classList.remove('dn');

      // hidden
      document.querySelector('.dados-ativacao').classList.add('dn');
      document.querySelector('.solicitacao-recursos').classList.add('dn');
      document.querySelector('.diretorio').classList.add('dn');
      document.querySelector('.documentacao-tecnica').classList.add('dn');
    },

    removeAdobeOptions() {
      // hidden
      document.querySelector('.adobe-options').classList.add('dn');
      document.querySelector('.so').classList.add('dn');

      // show
      document.querySelector('.dados-ativacao').classList.remove('dn');
      document.querySelector('.solicitacao-recursos').classList.remove('dn');
      document.querySelector('.diretorio').classList.remove('dn');
      document.querySelector('.documentacao-tecnica').classList.remove('dn');
    },

    getLogAdobeAcrobatDC() {

      let adobeID = '';
      let so = '';

      if (this.adobeId === 'ADOBE ID') {
        adobeID = `ADOBE ID
- Para ativação dos produtos, deve ser selecionado a opção CONTA PESSOAL
- A autenticação deve ser feita com o e-mail do colaborador e com a senha registrada no site do fabricante
- Caso a colaboradora não se recorde de sua senha, deve recuperar a senha ou registrar uma nova no site Adobe.com
 
- Se a autenticação no site do Adobe estiver funcionando, é necessário fazer logoff de todos os produtos Adobe e fazer novo acesso. Pode usar o autenticador Creative Cloud disponível na Central de Software para facilitar o processo de autenticação.`;
      } else {
        adobeID = `FEDERATED ID
- Para ativação dos produtos, deve ser selecionado a opção CONTA CORPORATIVA
- A autenticação deve ser feita com o e-mail do colaborador e com a senha de rede
- Caso a colaboradora não se autentique no aplicativo, realizar teste de autenticação no site Adobe.com
 
- Se a autenticação no site do Adobe estiver funcionando, é necessário fazer logoff de todos os produtos Adobe e fazer novo acesso. Pode usar o autenticador Creative Cloud disponível na Central de Software para facilitar o processo de autenticação.`;
      }

      // Log ---
      this.detalhes = `Autorizamos a instalação do ${this.software} na máquina do usuário:
      
Máquina: ${this.controleTi}
Dados de ativação: E-mail e senha do usuário
Solicitação de Recurso: Já cadastrado no Console ou número do chamado

Algumas informações importantes para que o produto seja ativado corretamente na estação da colaboradora:
- A estação da colaboradora deve estar com acesso à internet.
- O gerenciamento e instalação dos produtos não é feito pelo site do fabricante e nem pelo autenticador Creative Cloud disponível na Central de Software.
- Na instalação não devem ser usados instaladores baixados por meio do site do fabricante e sim, os instaladores homologados e disponíveis na rede, seguindo os procedimentos indicados nos manuais, conforme abaixo:

Diretório:
\\\\fswcorp\\cto\\SASM\\SOFTWARE_LICENCIADO\\Adobe Acrobat\\DC\\21.005.20060\\Instalador

Documentação Técnica:
\\\\fswcorp\\cto\\SASM\\DOCUMENTACAO_TECNICA\\Software\\LAUDO DE CERTIFICAÇÃO\\Adobe Acrobat\\DC

${adobeID}`
    },

    getLogDefault() {
      this.detalhes = `Autorizamos a instalação do ${this.software} na máquina do usuário:

        Máquina: ${this.controleTi}
Dados de ativação: ${this.dadosAtivacao}
Solicitação de Recurso: ${this.solicitacaoRecursos}

      Diretório:
${this.diretorio}

Documentação Técnica:
${this.documentacaoTecnica}`;
    },

    updateDetalhes() {
      switch (this.software) {
        case 'Adobe Acrobat DC':
          this.addAdobeOptions();
          this.getLogAdobeAcrobatDC();
          break;

        default:
          this.removeAdobeOptions();
          this.getLogDefault();
          break;
      }

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>
