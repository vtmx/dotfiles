<template>
  <div>
    <app-header />

    <main class="main changelog uk-container uk-container-small">
      <div class="uk-card">
        <h1 class="uk-h2 uk-text-center uk-text-uppercase">Changelog</h1>

        <h2 class="version">2.7.2</h2>
        <h3 class="date">2023-03-23</h3>
        <ul class="logs">
          <li class="log added">Em espera de resposta de mudança de responsabilidade.</li>
        </ul>

        <h2 class="version">2.7.1</h2>
        <h3 class="date">2023-03-03</h3>
        <ul class="logs">
          <li class="log added">SCCM Collection ID</li>
          <li class="log removed">Doc versão em homologação.</li>
        </ul>

        <h2 class="version">2.7.0</h2>
        <h3 class="date">2023-03-01</h3>
        <ul class="logs">
          <li class="log added">Página de pedido de descontinuação em homologação.</li>
        </ul>

        <h2 class="version">2.6.9</h2>
        <h3 class="date">2023-02-25</h3>
        <ul class="logs">
          <li class="log changed">Remover melhoria Íris em atendimento.</li>
        </ul>

        <h2 class="version">2.6.8</h2>
        <h3 class="date">2023-02-09</h3>
        <ul class="logs">
          <li class="log changed">Remove solicitante adicional quando não selecionado em homologação.</li>
        </ul>

        <h2 class="version">2.6.7</h2>
        <h3 class="date">2022-08-31</h3>
        <ul class="logs">
          <li class="log fixed">Soma de tamanho em homologação.</li>
        </ul>

        <h2 class="version">2.6.6</h2>
        <h3 class="date">2022-08-18</h3>
        <ul class="logs">
          <li class="log added">Log de direcionamento em homologacao.</li>
        </ul>

        <h2 class="version">2.6.5</h2>
        <h3 class="date">2022-08-06</h3>
        <ul class="logs">
          <li class="log added">Log de fechamento em homologacao.</li>
        </ul>

        <h2 class="version">2.6.4</h2>
        <h3 class="date">2022-07-20</h3>
        <ul class="logs">
          <li class="log changed">Melhoria nas logs de homologação.</li>
        </ul>

        <h2 class="version">2.6.3</h2>
        <h3 class="date">2022-07-02</h3>
        <ul class="logs">
          <li class="log added">Campo de equipamento testado e remove versão anterior em homologação.</li>
          <li class="log changed">Compra de software em homologação.</li>
          <li class="log changed">Página de changelog.</li>
        </ul>

        <h2 class="version">2.6.2</h2>
        <h3 class="date">2022-06-28</h3>
        <ul class="logs">
          <li class="log added">Melhoria Íris em inicio de atendimento.</li>
        </ul>

        <h2 class="version">2.6.1</h2>
        <h3 class="date">2022-06-11</h3>
        <ul class="logs">
          <li class="log changed">Log de informação em homologação.</li>
          <li class="log fixed">Link de espera em homologação.</li>
          <li class="log removed">Links gerais.</li>
        </ul>

        <h2 class="version">2.6.0</h2>
        <h3 class="date">2022-06-01</h3>
        <ul class="logs">
          <li class="log added">Página de error 404.</li>
          <li class="log changed">Tentativa de contato em remoto.</li>
        </ul>

        <h2 class="version">2.5.9</h2>
        <h3 class="date">2022-05-25</h3>
        <ul class="logs">
          <li class="log added">Fechamento de novo equipamento em remoto.</li>
          <li class="log added">Fechamento de equipamento reserva em remoto.</li>
          <li class="log added">Cacelamento de software que já existe em homologação.</li>
          <li class="log added">Cancelamento de falha na central de software em homologação.</li>
        </ul>

        <h2 class="version">2.5.8</h2>
        <h3 class="date">2022-05-16</h3>
        <ul class="logs">
          <li class="log changed">Contato em remoto.</li>
        </ul>

        <h2 class="version">2.5.7</h2>
        <h3 class="date">2022-05-07</h3>
        <ul class="logs">
          <li class="log added">Log de espera em homologação.</li>
          <li class="log changed">Apresentação em finalização do chat em atendimento.</li>
          <li class="log changed">Info em homologação.</li>
          <li class="log changed">Tentativa de contato em remoto.</li>
        </ul>

        <h3 class="date">2022-03-25</h3>
        <ul class="logs">
          <li class="log added">Grupo aprovador em homologação se software restrito ou licenciado.</li>
          <li class="log added">Assunto em emails de De Acordo em homologação.</li>
          <li class="log added">Hostname no email de teste em homologação.</li>
        </ul>

        <h2 class="version">2.5.5</h2>
        <h3 class="date">2022-03-16</h3>
        <ul class="logs">
          <li class="log added">Logs de cancelamento em homolocação.</li>
          <li class="log fixed">Info em homologação.</li>
        </ul>

        <h2 class="version">2.5.4</h2>
        <h3 class="date">2022-02-21</h3>
        <ul class="logs">
          <li class="log added">Logs de homolocação.</li>
          <li class="log fixed">Menus em homologação e vctp.</li>
        </ul>

        <h2 class="version">2.5.3</h2>
        <h3 class="date">2022-02-17</h3>
        <ul class="logs">
          <li class="log added">Menu homologação na página inicial.</li>
          <li class="log changed">Campo de pesquisa em atendimento.</li>
        </ul>

        <h2 class="version">2.5.2</h2>
        <h3 class="date">2022-02-10</h3>
        <ul class="logs">
          <li class="log added">Menu para homologação.</li>
          <li class="log fixed">Mudar de foco ao colar.</li>
        </ul>

        <h2 class="version">2.5.1</h2>
        <h3 class="date">2022-02-03</h3>
        <ul class="logs">
          <li class="log changed">Novo modelo para informações em homologação.</li>
        </ul>

        <h2 class="version">2.5.0</h2>
        <h3 class="date">2022-01-21</h3>
        <ul class="logs">
          <li class="log changed">Página de informações do pacote em homologação.</li>
        </ul>

        <h2 class="version">2.4.9</h2>
        <h3 class="date">2022-01-08</h3>
        <ul class="logs">
          <li class="log added">Página de informações do pacote em homologação.</li>
        </ul>

        <h2 class="version">2.4.8</h2>
        <h3 class="date">2021-12-23</h3>
        <ul class="logs">
          <li class="log fixed">Auto-preenchimento em tentativas de contato.</li>
        </ul>

        <h2 class="version">2.4.7</h2>
        <h3 class="date">2021-12-21</h3>
        <ul class="logs">
          <li class="log added">Gravação de chamado e nome do colaborador de contato em remoto.</li>
          <li class="log fixed">Opacidade no efeito de acordião e cores na mudança de cores.</li>
          <li class="log removed">Ação de fechamento em remoto.</li>
        </ul>

        <h2 class="version">2.4.6</h2>
        <h3 class="date">2021-12-11</h3>
        <ul class="logs">
          <li class="log added">Frases de strike em atendimento.</li>
          <li class="log added">Frase para pesquisa de atendimento.</li>
          <li class="log changed">Efeito de acordião sobre finalização em atendimento e remoto.</li>
        </ul>

        <h2 class="version">2.4.5</h2>
        <h3 class="date">2021-12-09</h3>
        <ul class="logs">
          <li class="log added">Abas em chat.</li>
          <li class="log added">Log de reinicio de equipapmento em chat.</li>
          <li class="log fixed">Finalização de fechamento em remoto.</li>
        </ul>

        <h2 class="version">2.4.4</h2>
        <h3 class="date">2021-12-08</h3>
        <ul class="logs">
          <li class="log added">Logs de finalizações em atendimento e remoto.</li>
          <li class="log added">Transferência em atendimento.</li>
        </ul>

        <h2 class="version">2.4.3</h2>
        <h3 class="date">2021-10-11</h3>
        <ul class="logs">
          <li class="log fixed">Campo select no dark mode.</li>
        </ul>

        <h2 class="version">2.4.2</h2>
        <h3 class="date">2021-10-02</h3>
        <ul class="logs">
          <li class="log added">Agradecimento à Thainá Machado Aquino.</li>
          <li class="log added">Agendamento de férias/licença em remoto.</li>
          <li class="log fixed">Cor do elemento option quando select é selecionado.</li>
          <li class="log fixed">Palavra solicitação para tarefa de início pós-agendamento em remoto.</li>
        </ul>

        <h2 class="version">2.4.1</h2>
        <h3 class="date">2021-09-25</h3>
        <ul class="logs">
          <li class="log added">Tentativa de contato e-mail instalação de software em remoto.</li>
          <li class="log added">Tentativa de contato e-mail incidente/tareafas em remoto.</li>
          <li class="log changed">Modificado nome field service para remoto.</li>
          <li class="log changed">Tentativa de contato em remoto.</li>
          <li class="log changed">Palavra Maximo para Service Now em log de andamento.</li>
          <li class="log changed">Destaque campo válido em darkmode.</li>
          <li class="log changed">Limitar redimensionamento do campo de texto na vertical.</li>
        </ul>

        <h2 class="version">2.4.0</h2>
        <h3 class="date">2021-07-04</h3>
        <ul class="logs">
          <li class="log added">Dark mode em homenagem ao técnico Gianluas.</li>
          <li class="log added">Principais logs de atendimento no chat.</li>
          <li class="log added">Perda de contato em atendimento.</li>
        </ul>

        <h2 class="version">2.3.9</h2>
        <h3 class="date">2021-05-01</h3>
        <ul class="logs">
          <li class="log changed">Identidade visual.</li>
        </ul>

        <h2 class="version">2.3.8</h2>
        <h3 class="date">2021-04-14</h3>
        <ul class="logs">
          <li class="log changed">Torna opicional campo de SO em fechamento de atendimento e field.</li>
        </ul>

        <h2 class="version">2.3.7</h2>
        <h3 class="date">2021-03-24</h3>
        <ul class="logs">
          <li class="log changed">Hierarquia de links.</li>
        </ul>

        <h2 class="version">2.3.6</h2>
        <h3 class="date">2021-03-10</h3>
        <ul class="logs">
          <li class="log added">Cópia automática ao gerar log.</li>
        </ul>

        <h2 class="version">2.3.5</h2>
        <h3 class="date">2021-03-08</h3>
        <ul class="logs">
          <li class="log changed">Horário de almoço em logs de direcionamento em Atendimento.</li>
        </ul>

        <h2 class="version">2.3.4</h2>
        <h3 class="date">2021-03-04</h3>
        <ul class="logs">
          <li class="log changed">Status para resolido caso seja a 4ª tentativa de contato.</li>
        </ul>

        <h2 class="version">2.3.3</h2>
        <h3 class="date">2021-03-01</h3>
        <ul class="logs">
          <li class="log added">Horário de almoço em Atendimento.</li>
        </ul>

        <h2 class="version">2.3.2</h2>
        <h3 class="date">2021-01-28</h3>
        <ul class="logs">
          <li class="log added">Sistemas operacionais nas logs de Fechamento.</li>
          <li class="log changed">Frase procedimento executados por solução do Fechamento em Atendimento.</li>
          <li class="log changed">Estado nas logs de Agendamento para Aguardando agendamento.</li>
          <li class="log changed">Nome de VPN e impressora para padrão em Direcionamento.</li>
          <li class="log removed">Obrigatoriedade dos campos Contole TI e Telefone em Atendimento.</li>
          <li class="log removed">Página de Equipamento e Periférico em Direcionamento.</li>
          <li class="log removed">Redirecionamento em Atendimento.</li>
        </ul>

        <h2 class="version">2.3.1</h2>
        <h3 class="date">2021-01-22</h3>
        <ul class="logs">
          <li class="log added">Nova lista de softwares em fechamento de Atendimento e Fieldservice.</li>
        </ul>

        <h2 class="version">2.3.0</h2>
        <h3 class="date">2021-01-18</h3>
        <ul class="logs">
          <li class="log added">Novo grupo chamado Atendimento.</li>
        </ul>

        <h2 class="version">2.2.1</h2>
        <h3 class="date">2020-11-18</h3>
        <ul class="logs">
          <li class="log changed">Incidente como prioridade nas escolhas entre incidente e tarefa.</li>
        </ul>

        <h2 class="version">2.2.0</h2>
        <h3 class="date">2020-10-25</h3>
        <ul class="logs">
          <li class="log added">Campo de estado ao gerar log.</li>
          <li class="log changed">Roubo / Furto SRTI por Marketplace em Manutenção.</li>
          <li class="log changed">De Skype para Teams em todas as logs.</li>
          <li class="log fixed">Tamanho do cabeçalho e rodapé.</li>
          <li class="log removed">Tipo de chamado ao gerar log.</li>
        </ul>

        <h2 class="version">2.1.5</h2>
        <h3 class="date">2020-09-08</h3>
        <ul class="logs">
          <li class="log fixed">Chamado duplicado.</li>
        </ul>

        <h2 class="version">2.1.4</h2>
        <h3 class="date">2020-07-22</h3>
        <ul class="logs">
          <li class="log added">Número da tentativa de contato nas logs.</li>
        </ul>

        <h2 class="version">2.1.3</h2>
        <h3 class="date">2020-07-01</h3>
        <ul class="logs">
          <li class="log fixed">Campo de chip por IMEI no fechamento de mobilidade.</li>
        </ul>

        <h2 class="version">2.1.2</h2>
        <h3 class="date">2020-06-20</h3>
        <ul class="logs">
          <li class="log changed">Tentativa de contato para o Service Now.</li>
        </ul>

        <h2 class="version">2.1.1</h2>
        <h3 class="date">2020-06-17</h3>
        <ul class="logs">
          <li class="log added">Página de atendimento do grupo VCTP.</li>
          <li class="log added">Campo ação no fechamento de field service.</li>
          <li class="log removed">Campo funcional no fechamento de mobilidade.</li>
          <li class="log removed">Campo funcional no fechamento de telefonia.</li>
        </ul>

        <h2 class="version">2.1.0</h2>
        <h3 class="date">2020-06-15</h3>
        <ul class="logs">
          <li class="log changed">Término do Máximo, início do ServiceNow, início das edições.</li>
        </ul>

        <h2 class="version">2.0.1</h2>
        <h3 class="date">2020-02-27</h3>
        <ul class="logs">
          <li class="log added">Pular form ao colar em páginas de fechamento.</li>
        </ul>

        <h2 class="version">2.0.0</h2>
        <h3 class="date">2019-09-23</h3>
        <ul class="logs">
          <li class="log changed">Visual totalmente remodelado.</li>
          <li class="log changed">Acessibilidade melhorada.</li>
          <li class="log changed">Link atualiza.</li>
        </ul>

        <h2 class="version">1.5.5</h2>
        <h3 class="date">2019-09-23</h3>
        <ul class="logs">
          <li class="log changed">substituição de aparelho em mobilidade.</li>
          <li class="log changed">aparalho entregue na expedição em mobilidade.</li>
        </ul>

        <h2 class="version">1.5.4</h2>
        <h3 class="date">2019-09-02</h3>
        <ul class="logs">
          <li class="log changed">Links de telecom.</li>
          <li class="log changed">Locais dos arquivos de links repetidos.</li>
          <li class="log changed">Páginas inciais das áreas.</li>
        </ul>

        <h2 class="version">1.5.3</h2>
        <h3 class="date">2019-05-13</h3>
        <ul class="logs">
          <li class="log added">Tentativa de contato pró-ativa em fieldservice e mobilidade.</li>
        </ul>

        <h2 class="version">1.5.2</h2>
        <h3 class="date">2019-04-20</h3>
        <ul class="logs">
          <li class="log changed">Fechamento de chamado em Field Service.</li>
          <li class="log changed">Contato Skype para 5 minutos.</li>
        </ul>

        <h2 class="version">1.5.1</h2>
        <h3 class="date">2019-04-18</h3>
        <ul class="logs">
          <li class="log added">Lista de softwares em fechamento.</li>
          <li class="log changed">Tempo para 5 minutos em tentativa de contato.</li>
        </ul>

        <h2 class="version">1.5.0</h2>
        <h3 class="date">2019-01-29</h3>
        <ul class="logs">
          <li class="log changed">Retira tipo na fechamento.</li>
        </ul>

        <h2 class="version">1.4.9</h2>
        <h3 class="date">2018-11-17</h3>
        <ul class="logs">
          <li class="log added">contato por Skype em Field Service e Mobilidade.</li>
          <li class="log changed">tentativa de contato em Field Service e Mobilidade.</li>
        </ul>

        <h2 class="version">1.4.8</h2>
        <h3 class="date">2018-11-17</h3>
        <ul class="logs">
          <li class="log added">Log em andamento.</li>
          <li class="log changed">tentativa de contato.</li>
          <li class="log removed">Cancelamento por falta de contato.</li>
        </ul>

        <h2 class="version">1.4.7</h2>
        <h3 class="date">2018-10-15</h3>
        <ul class="logs">
          <li class="log changed">tentativa de contato.</li>
          <li class="log removed">tentativa de contato oficial.</li>
        </ul>

        <h2 class="version">1.4.6</h2>
        <h3 class="date">2018-10-10</h3>
        <ul class="logs">
          <li class="log added">direcionamento para correio.</li>
        </ul>

        <h2 class="version">1.4.5</h2>
        <h3 class="date">2018-09-15</h3>
        <ul class="logs">
          <li class="log added">direcionamento para correio.</li>
          <li class="log changed">Logs de fechamento resolvido tecnicamente.</li>
        </ul>

        <h2 class="version">1.4.4</h2>
        <h3 class="date">2018-08-15</h3>
        <ul class="logs">
          <li class="log changed">Fechamento de logs.</li>
        </ul>

        <h2 class="version">1.4.3</h2>
        <h3 class="date">2018-08-11</h3>
        <ul class="logs">
          <li class="log added">Agradecimento à Cristiane Neri.</li>
          <li class="log changed">Estilo TIVIT.</li>
        </ul>

        <h2 class="version">1.4.2</h2>
        <h3 class="date">2018-03-10</h3>
        <ul class="logs">
          <li class="log changed">Pequana frase no termo de entrega.</li>
        </ul>

        <h2 class="version">1.4.1</h2>
        <h3 class="date">2017-11-21</h3>
        <ul class="logs">
          <li class="log added">Desktop, notebook e home office para equipamentos da Redecard.</li>
          <li class="log added">Fechamento de chamado VIP em fieldservice.</li>
          <li class="log fixed">fechamento em telecom e field service.</li>
        </ul>

        <h2 class="version">1.4.0</h2>
        <h3 class="date">2017-09-22</h3>
        <ul class="logs">
          <li class="log added">Diversas logs na página de mobilidade.</li>
          <li class="log added">fechamento de entrega de periféricos em field service.</li>
          <li class="log changed">Ordenação no menu de pendência.</li>
          <li class="log fixed">Data atual na antecipação de agendamento em field service.</li>
          <li class="log fixed">Campo de teste no fechamento de chamados.</li>
        </ul>

        <h2 class="version">1.3.3</h2>
        <h3 class="date">2017-09-01</h3>
        <ul class="logs">
          <li class="log changed">Correção interoperabilidade entre os navegadores.</li>
        </ul>

        <h2 class="version">1.3.2</h2>
        <h3 class="date">2017-08-30</h3>
        <ul class="logs">
          <li class="log changed">Margem do menu para funcionar no IE sem a fonte padrão.</li>
          <li class="log changed">Alterações no espaçamento dos botões de ação.</li>
        </ul>

        <h2 class="version">1.3.1</h2>
        <h3 class="date">2017-07-19</h3>
        <ul class="logs">
          <li class="log changed">Pequenas correções de caminhos.</li>
          <li class="log changed">Em telecom, modificado alguns campos em início da pendência.</li>
        </ul>

        <h2 class="version">1.3.0</h2>
        <h3 class="date">2017-07-19</h3>
        <ul class="logs">
          <li class="log changed">Pequenas correções de caminhos.</li>
          <li class="log changed">Em telecom, modificado alguns campos em início da pendência.</li>
        </ul>

        <h2 class="version">1.2.9</h2>
        <h3 class="date">2017-07-04</h3>
        <ul class="logs">
          <li class="log added">Atendimento na localidade é feito em horário comercial em telecom.</li>
          <li class="log fixed">Troca de equipamento refresh em fechamento.</li>
        </ul>

        <h2 class="version">1.2.8</h2>
        <h3 class="date">2017-06-29</h3>
        <ul class="logs">
          <li class="log fixed">Direcionamento para fechamento em telecom.</li>
        </ul>

        <h2 class="version">1.2.7</h2>
        <h3 class="date">2017-06-24</h3>
        <ul class="logs">
          <li class="log added">Atualização de pendência em telecom.</li>
          <li class="log added">Localidade do chamado bloco 2 em telecom.</li>
          <li class="log changed">Nome altiris no lugar de gati nos fechamentos de chamado.</li>
        </ul>

        <h2 class="version">1.2.6</h2>
        <h3 class="date">2017-05-18</h3>
        <ul class="logs">
          <li class="log added">Em manutenção foi adicionado o item Orçamento Aprovado - Aguardando CDC.</li>
        </ul>

        <h2 class="version">1.2.5</h2>
        <h3 class="date">2017-03-10</h3>
        <ul class="logs">
          <li class="log added">Grupo de telecom.</li>
          <li class="log added">Título nas páginas de linha de serviço.</li>
          <li class="log changed">Hierarquia de pastas.</li>
        </ul>

        <h2 class="version">1.2.4</h2>
        <h3 class="date">2017-03-09</h3>
        <ul class="logs">
          <li class="log added">Categoria de grupos de atendimento.</li>
        </ul>

        <h2 class="version">1.2.3</h2>
        <h3 class="date">2017-02-10</h3>
        <ul class="logs">
          <li class="log added">Logs de mobilidade.</li>
          <li class="log changed">Auto-inclusão de quatidade de material utilizado, base de conhecimento não e testes.</li>
          <li class="log changed">Fechamento de vídeo/tele, incluído data atual.</li>
        </ul>

        <h2 class="version">1.2.2</h2>
        <h3 class="date">2016-10-03</h3>
        <ul class="logs">
          <li class="log changed">Prefixo e sufixo no nome das máquinas no fechamento de chamado.</li>
        </ul>

        <h2 class="version">1.2.1</h2>
        <h3 class="date">2016-09-19</h3>
        <ul class="logs">
          <li class="log fixed">Informação das WORKLOGS (Tipos de Log).</li>
        </ul>

        <h2 class="version">1.2.0</h2>
        <h3 class="date">2016-09-06</h3>
        <ul class="logs">
          <li class="log added">Colocar a informação das WORKLOGS (Tipos de Log).</li>
          <li class="log added">Fechamento, inserido sufixo -IS (para máquinas da Seguradora).</li>
          <li class="log added">Inserir log do novo processo de Enxoval de licenças.</li>
          <li class="log added">Em andamento de indisponibilidade da ferramenta Maximo.</li>
          <li class="log added">Inserido campo de ID do TMS do fechamento de vídeo-tele.</li>
          <li class="log changed">Selecionar campo de resumo primeiro.</li>
          <li class="log changed">Direcionamento de Chamados para 3° Nível.</li>
          <li class="log changed">Informação sobre "previsão de atualização" na direc para fila manutenção.</li>
        </ul>

        <h2 class="version">1.1.9</h2>
        <h3 class="date">2016-06-25</h3>
        <ul class="logs">
          <li class="log added">Fechamento para acompanhamento.</li>
          <li class="log added">Breakfix de rede.</li>
          <li class="log changed">Fechamento para recolhimento.</li>
          <li class="log removed">Manutençaõ de headset.</li>
        </ul>

        <h2 class="version">1.1.8</h2>
        <h3 class="date">2016-06-02</h3>
        <ul class="logs">
          <li class="log added">Roubo / furto SRTI.</li>
          <li class="log changed">Laboratório.</li>
          <li class="log removed">Reconhecimento, informativo e fechamento de acompanhamento.</li>
        </ul>

        <h2 class="version">1.1.7</h2>
        <h3 class="date">2016-06-01</h3>
        <ul class="logs">
          <li class="log added">Reconhecimento de chamado.</li>
          <li class="log added">Informativo.</li>
          <li class="log added">Chamado aberto para outro usuário.</li>
          <li class="log added">Treinamento de abandono de prédio.</li>
          <li class="log added">Pendência quando houver paralização sindical.</li>
          <li class="log added">Direcionamento indevido.</li>
          <li class="log added">Fechamento para acompanhamentos.</li>
        </ul>

        <h2 class="version">1.1.6</h2>
        <h3 class="date">2016-05-29</h3>
        <ul class="logs">
          <li class="log added">Campo de comentários adicionais em todas as logs.</li>
          <li class="log changed">Ordem dos campos da janela de log.</li>
        </ul>

        <h2 class="version">1.1.5</h2>
        <h3 class="date">2016-05-26</h3>
        <ul class="logs">
          <li class="log added">Mensagens informativas em algumas logs.</li>
          <li class="log changed">Alterações nas logs de manutenção.</li>
        </ul>

        <h2 class="version">1.1.4</h2>
        <h3 class="date">2016-05-02</h3>
        <ul class="logs">
          <li class="log added">Troca de equipamento leasing.</li>
          <li class="log fixed">Vídeo / tele.</li>
        </ul>

        <h2 class="version">1.1.3</h2>
        <h3 class="date">2016-04-19</h3>
        <ul class="logs">
          <li class="log fixed">Recolhimento.</li>
        </ul>

        <h2 class="version">1.1.2</h2>
        <h3 class="date">2016-04-06</h3>
        <ul class="logs">
          <li class="log added">Prévia de pendência de furto.</li>
          <li class="log fixed">IU na fechamento.</li>
          <li class="log removed">Reagendamento.</li>
        </ul>

        <h2 class="version">11.1</h2>
        <h3 class="date">2016-02-26</h3>
        <ul class="logs">
          <li class="log fixed">Correção de logs.</li>
        </ul>

        <h2 class="version">1.1.0</h2>
        <h3 class="date">2016-02-26</h3>
        <ul class="logs">
          <li class="log changed">Redução no menu, aumentando a área de conteúdo.</li>
          <li class="log changed">Diminuição no tempo de transição do menu.</li>
        </ul>

        <h2 class="version">1.0.9</h2>
        <h3 class="date">2016-02-25</h3>
        <ul class="logs">
          <li class="log changed">Modificações de diversas logs.</li>
          <li class="log changed">Melhoria de preenchimento.</li>
        </ul>

        <h2 class="version">1.0.8</h2>
        <h3 class="date">2016-02-23</h3>
        <ul class="logs">
          <li class="log changed">Agendamento.</li>
          <li class="log changed">Cancelamento devido período ausente.</li>
          <li class="log added">Reamejamento.</li>
          <li class="log added">Tentativa de contato oficial.</li>
          <li class="log added">Inclusão do campo de resumo ao gerar log.</li>
          <li class="log fixed">Algumas sentenças.</li>
        </ul>

        <h2 class="version">1.0.7</h2>
        <h3 class="date">2016-02-18</h3>
        <ul class="logs">
          <li class="log changed">Atendimento pós-agendamento.</li>
          <li class="log changed">Antecipação de agendamento.</li>
          <li class="log changed">Fechamento de vídeo/tele.</li>
        </ul>

        <h2 class="version">1.0.6</h2>
        <h3 class="date">2016-02-04</h3>
        <ul class="logs">
          <li class="log changed">Fechamento de vídeo/tele otimizado para datas.</li>
          <li class="log added">Nova pós.</li>
        </ul>

        <h2 class="version">1.0.5</h2>
        <h3 class="date">2015-12-15</h3>
        <ul class="logs">
          <li class="log changed">Novo logo e cores.</li>
          <li class="log added">Auto seleção ao gerar log.</li>
          <li class="log fixed">Algumas logs.</li>
        </ul>

        <h2 class="version">1.0.4</h2>
        <h3 class="date">2015-11-04</h3>
        <ul class="logs">
          <li class="log added">Interface para alerta de erro.</li>
          <li class="log added">Fechamento do lightbox com a tecla Esc.</li>
          <li class="log fixed">Validador de campos após clicar em gerar log.</li>
        </ul>

        <h2 class="version">1.0.3</h2>
        <h3 class="date">2015-11-01</h3>
        <ul class="logs">
          <li class="log added">Validador de campos após clicar em gerar log.</li>
          <li class="log added">Página de changelog baseado em <a href="http://keepachangelog.com/pt-BR/">keepachangelog</a>.</li>
        </ul>

        <h2 class="version">1.0.2</h2>
        <h3 class="date">2015-10-31</h3>
        <ul class="logs">
          <li class="log added">Design para a nova identidade visual Hewlett Packard Enterprise.</li>
          <li class="log added">Plugin <a href="http://ericleads.com/h5validate/">placeholder.js</a> para utilizar o atributo no IE8.</li>
          <li class="log added">Plugin <a href="https://mathiasbynens.github.io/jquery-placeholder/">h5validate.js</a> para validar campos com o atributo required no IE8.</li>
        </ul>

        <h2 class="version">1.0.1</h2>
        <h3 class="date">2015-09-30</h3>
        <ul class="logs">
          <li class="log added">Divulgado a aplicação.</li>
        </ul>

        <h2 class="version">1.0.0</h2>
        <h3 class="date">2015-10-28</h3>
        <ul class="logs">
          <li class="log changed">Tipo de equipamento na página de fechamento.</li>
        </ul>
      </div>
    </main>

    <app-footer />
  </div>
</template>

<script>
import AppHeader from '~/components/app-header.vue';
import AppFooter from '~/components/app-footer.vue';

export default {
  components: {
    AppHeader,
    AppFooter,
  },
};
</script>
