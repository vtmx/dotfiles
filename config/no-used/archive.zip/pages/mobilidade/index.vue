<template>
  <div>
    {{ titulo }}
  </div>
</template>

<script>
// Load menu
localStorage.setItem('layout', 'mobilidade')

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.titulo}`,
    };
  },
  data() {
    return {
      titulo: 'Mobilidade'
    }
  }
};
</script>
