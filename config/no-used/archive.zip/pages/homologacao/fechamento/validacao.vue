<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-1">
        <label for="link" class="uk-form-label required">Link de validação</label>
        <input id="link" type="text" class="uk-input" required v-model="link" @input="updateDetalhes" />
      </div>
    </div><!-- uk-grid -->

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Validação',
      status: 'Em espera do solicitante',
      detalhes: '',
      // ---
      link: ''
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `Favor validar o funcionamento do pacote através do link abaixo para podermos publicá-lo:
${this.link}`;
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>