<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Compra de licença',
      status: 'Encerrado',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `O processo de compras de licença corporativa passa pelas seguintes etapas:

- Você deve fazer a Defesa de Orçamento/CINVEST. Para este processo é necessário o preenchimento do FID (Formulário de Investimento e Despesa), por meio do link: https://aut-sust.itau/FG5/PortalCompras/#/login?state=%2Fhome
- Após a aprovação, o time de compras providencia a Criação de código no SAP,  a abertura de carrinho de compras, efetua a negociação com os fornecedores e faz o envio do pedido.
- Após a emissão do pedido a equipe de Gestão de Licenças, acompanha a entrega, recebe o produto, faz o cadastro nos controles de licenças e libera a licença para seu uso.
- Quando a licença estiver liberada, se o produto ainda não estiver homologado, você deve solicitar a homologação do mesmo. 

Reforçamos que não podem ser utilizadas licenças pessoais na instituição. Todos os produtos para estarem compliance, devem usar licenças corporativas.`;
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>