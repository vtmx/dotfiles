<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Falta de informações',
      status: 'Encerrado',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `Para o processo de certificação de software é necessário informar o link do executável off-line para download ou ter anexado o executável, bem como o preenchimento correto de todos os campos da solicitação, pois dessa forma será possível orientar e atender à solicitação.
 
Para processos de incidentes, o fluxo mais eficaz e a verificação e abertura de solicitação ao time de suporte através do chat de atendimento do Service Now clicando no avatar da Iris localizado no canto inferior direito: https://itau.service-now.com/tech
 
Como não temos ação para dissolver a atividade nessa fila, a solicitação será cancelada.`;
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>