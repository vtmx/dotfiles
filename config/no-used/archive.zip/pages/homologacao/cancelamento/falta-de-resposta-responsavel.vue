<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Falta de Resposta do Responsável',
      status: 'Encerrado',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `Não recebemos o de acordo de quem seria o Owner(dono) do software, por esse motivo a ocorrência será cancelada.`;
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>