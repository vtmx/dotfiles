<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div class="homologacao-checklist">
      <ul class="uk-list checkboxes">
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="radio" class="uk-radio" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
        <li><label><input type="checkbox" class="uk-checkbox" @change="updateDetalhes"> Item 1</label></li>
      </ul>
    </div>

  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Checklist',
      status: 'Em andamento',
      detalhes: '',
      // ---
      ritm: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>