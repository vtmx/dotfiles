<template>
  <div>
    <div class="uk-margin-bottom uk-text-right">
      <button id="limpar-campos" class="uk-button uk-button-primary" @click.prevent="resetState" uk-scroll>Limpar</button>
      <button class="uk-button uk-button-primary uk-margin-small-left" @click.prevent="goTo('bottom')"><span uk-icon="icon:triangle-down"></span></button>
    </div>

    <hr>

    <div id="homologacao">
      <h2 class="uk-h4 uk-margin-small">Solicitação</h2>

      <div uk-grid>
        <div class="uk-width-1-2">
          <label for="sof-solicitacao-numero" class="uk-form-label required">Número</label>
          <input id="sof-solicitacao-numero" type="text" class="uk-input" required v-model="info.sofSolicitacaoNumero" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="data-inicio" class="uk-form-label required">Data início</label>
          <date-pick v-model="info.dataInicio" @input="updateDetalhes" :displayFormat="'DD/MM/YYYY'" :prevMonthCaption="'Anterior'" :nextMonthCaption="'Próximo'" :setTimeCaption="'Hora:'" :weekdays="['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom']" :months="['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembero', 'Outubro', 'Novembero', 'Dezembro']"> </date-pick>
        </div>

        <div class="uk-width-1-3">
          <label for="sof-ambiente" class="uk-form-label required">Ambiente</label>
          <select id="sof-ambiente" class="uk-select" v-model="info.sofAmbiente" @change="updateDetalhes">
            <option>Itaú-Unibanco</option>
            <option>Rede</option>
            <option>IBBA</option>
          </select>
        </div>

        <div class="uk-width-1-3">
          <label for="sof-categoria" class="uk-form-label required">Categoria</label>
          <select id="sof-categoria" class="uk-select" v-model="info.sofCategoria" @change="updateDetalhes">
            <option>Corporativo</option>
            <option>Restrito</option>
            <option>Licenciado</option>
          </select>
        </div>

        <div class="uk-width-1-3">
          <label for="sof-tipo-licenca" class="uk-form-label required">Tipo de licença</label>
          <select id="sof-tipo-licenca" class="uk-select" v-model="info.sofTipoLicenca" @change="updateDetalhes">
            <option>Comercial (pago)</option>
            <option>Freeware (gratuito)</option>
            <option>Open Source (gratuito)</option>
            <option>Trial (teste)</option>
          </select>
        </div>
      </div><!-- .grid -->

      <hr>

      <h2 class="uk-h4 uk-margin-small">Analista</h2>
      <div uk-grid>
        <div class="uk-width-1-3">
          <label for="analista-nome" class="uk-form-label required">Nome</label>
          <input id="analista-nome" type="text" class="uk-input" required v-model="info.analistaNome" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="analista-email" class="uk-form-label required">Email</label>
          <input id="analista-email" type="text" class="uk-input" required v-model="info.analistaEmail" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="revisor-nome" class="uk-form-label required">Revisor</label>
          <input id="revisor-nome" type="text" class="uk-input" required v-model="info.revisorNome" @input="updateDetalhes" />
        </div>
      </div><!-- .grid -->

      <hr>

      <h2 class="uk-h4 uk-margin-small">Solicitante</h2>
      <div uk-grid>
        <div class="uk-width-1-2">
          <label for="solicitante-nome" class="uk-form-label required">Nome</label>
          <input id="solicitante-nome" type="text" class="uk-input" required v-model="info.solicitanteNome" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="solicitante-email" class="uk-form-label required">Email</label>
          <input id="solicitante-email" type="text" class="uk-input" required v-model="info.solicitanteEmail" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="solicitante-func" class="uk-form-label required">Funcional</label>
          <input id="solicitante-func" type="text" class="uk-input" required v-model="info.solicitanteFunc" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="coordenacao" class="uk-form-label required">Coordenacao (Dep)</label>
          <input id="coordenacao" type="text" class="uk-input" required v-model="info.coordenacao" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="gerencia" class="uk-form-label required">Gerencia</label>
          <input id="gerencia" type="text" class="uk-input" required v-model="info.gerencia" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="solicitante-racf" class="uk-form-label required">Racf</label>
          <input id="solicitante-racf" type="text" class="uk-input" required v-model="info.solicitanteRacf" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-1" style="margin-top: 24px;">
          <label><input id="toggle-solicitante-adicional" type="checkbox" class="uk-checkbox" @change="adicionaSolicitanteAdicional($event)"> Solicitante adicional</label>
        </div>

      </div><!-- .grid -->

      <hr>

      <div class="solicitante-adicional dn">
        <h2 class="uk-h4 uk-margin-small">Solicitante adicional</h2>
        <div uk-grid>
          <div class="uk-width-1-2">
            <label for="solicitante-adicional-nome" class="uk-form-label required">Nome</label>
            <input id="solicitante-adicional-nome" type="text" class="uk-input" required v-model="info.solicitanteAdicionalNome" @input="updateDetalhes" />
          </div>

          <div class="uk-width-1-2">
            <label for="solicitante-adicional-email" class="uk-form-label required">Email</label>
            <input id="solicitante-adicional-email" type="text" class="uk-input" required v-model="info.solicitanteAdicionalEmail" @input="updateDetalhes" />
          </div>

          <div class="uk-width-1-2">
            <label for="solicitante-adicional-func" class="uk-form-label required">Funcional</label>
            <input id="solicitante-adicional-func" type="text" class="uk-input" required v-model="info.solicitanteAdicionalFunc" @input="updateDetalhes" />
          </div>

          <div class="uk-width-1-2">
            <label for="solicitante-adicional-racf" class="uk-form-label required">Racf</label>
            <input id="solicitante-adicional-racf" type="text" class="uk-input" required v-model="info.solicitanteAdicionalRacf" @input="updateDetalhes" />
          </div>
        </div><!-- .grid -->

        <hr>
      </div><!-- solicitante-adicional -->

      <h2 class="uk-h4 uk-margin-small">Responsável</h2>

      <div class="uk-width-1-1" style="margin: 24px 0 24px 0;">
        <label><input id="" type="checkbox" class="uk-checkbox" @change="clonaSolicitante($event)"> Mesmo solicitante</label>
      </div>

      <div uk-grid>
        <div class="uk-width-1-2">
          <label for="sof-responsavel-nome" class="uk-form-label required">Nome</label>
          <input id="sof-responsavel-nome" type="text" class="uk-input" required v-model="info.sofResponsavelNome" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-responsavel-email" class="uk-form-label required">Email</label>
          <input id="sof-responsavel-email" type="text" class="uk-input" required v-model="info.sofResponsavelEmail" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-responsavel-func" class="uk-form-label required">Funcional</label>
          <input id="sof-responsavel-func" type="text" class="uk-input" required v-model="info.sofResponsavelFunc" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-responsavel-racf" class="uk-form-label required">Racf</label>
          <input id="sof-responsavel-racf" type="text" class="uk-input" required v-model="info.sofResponsavelRacf" @input="updateDetalhes" />
        </div>
      </div><!-- .grid -->

      <hr>

      <div class="categoria-depende dn">
        <h2 class="uk-h4 uk-margin-small">Grupo Aprovador</h2>
        <div uk-grid>
          <div class="uk-width-1-1">
            <label for="sof-grupo-aprovador" class="uk-form-label required">Nome</label>
            <input id="sof-grupo-aprovador" type="text" class="uk-input" required v-model="info.sofGrupoAprovador" @input="updateDetalhes" />
          </div>
        </div><!-- .grid -->

        <hr>
      </div><!-- .grupo-aprovador -->

      <h2 class="uk-h4 uk-margin-small">Software</h2>
      <div uk-grid>
        <div class="uk-width-1-3">
          <label for="sof-nome" class="uk-form-label required">Nome do software</label>
          <input id="sof-nome" type="text" class="uk-input" required v-model="info.sofNome" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="sof-versao" class="uk-form-label required">Versão</label>
          <input id="sof-versao" type="text" class="uk-input" required v-model="info.sofVersao" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="sof-arquitetura" class="uk-form-label required">Arquitetura</label>
          <select id="sof-arquitetura" class="uk-select" v-model="info.sofArquitetura" @change="updateDetalhes">
            <option>64bits</option>
            <option>32bits</option>
            <option>32/64bits</option>
          </select>
        </div>

        <div class="uk-width-1-3">
          <label for="sof-descricao" class="uk-form-label required">Descrição</label>
          <input id="sof-descricao" class="uk-input" required v-model="info.sofDescricao" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="sof-fabricante-nome" class="uk-form-label required">Fabricante</label>
          <input id="sof-fabricante-nome" type="text" class="uk-input" required v-model="info.sofFabricanteNome" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="sof-fabricante-site" class="uk-form-label">Site</label>
          <input id="sof-fabricante-site" type="text" class="uk-input" v-model="info.sofFabricanteSite" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-display-name" class="uk-form-label required">Display name</label>
          <input id="sof-display-name" type="text" class="uk-input" required v-model="info.sofDisplayName" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-display-version" class="uk-form-label required">Display version</label>
          <input id="sof-display-version" type="text" class="uk-input" required v-model="info.sofDisplayVersion" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-tamanho-setup" class="uk-form-label required">Tamanho setup (MB)</label>
          <input id="sof-tamanho-setup" type="text" class="uk-input" placeholder="0.000" required v-model="info.sofTamanhoSetup" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-tamanho-executavel" class="uk-form-label required">Tamanho instalado (MB)</label>
          <input id="sof-tamanho-executavel" type="text" class="uk-input" placeholder="0.000" required v-model="info.sofTamanhoInstalado" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-exe-caminho" class="uk-form-label required">Caminho pasta software</label>
          <input id="sof-exe-caminho" type="text" class="uk-input" required v-model="info.sofExeCaminho" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-exe-nome" class="uk-form-label required">Nome do executável</label>
          <input id="sof-exe-nome" type="text" class="uk-input" required v-model="info.sofExeNome" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-instalacao-comando" class="uk-form-label">Comando de instalação</label>
          <input id="sof-instalacao-comando" type="text" class="uk-input" v-model="info.sofInstalacaoComando" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-instalacao-parametro" class="uk-form-label">Parâmetro de instalação</label>
          <input id="sof-instalacao-parametro" type="text" class="uk-input" v-model="info.sofInstalacaoParamentro" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-desinstalacao-comando" class="uk-form-label">Comando de desinstalação</label>
          <input id="sof-desinstalacao-comando" type="text" class="uk-input" v-model="info.sofDesinstalacaoComando" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-desinstalacao-parametro" class="uk-form-label">Parâmetro de desinstalação</label>
          <input id="sof-desinstalacao-parametro" type="text" class="uk-input" v-model="info.sofDesinstalacaoParamentro" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-tipo-instalador" class="uk-form-label">Tipo de instalador</label>
          <select id="sof-tipo-instalador" class="uk-select" v-model="info.sofTipoInstalador" @change="updateDetalhes">
            <option></option>
            <option>InstallAnywhere</option>
            <option>InstallAware</option>
            <option>Inno Setup</option>
            <option>InstallShield</option>
            <option>Nullsof</option>
            <option>Microsoft Installer (MSI)</option>
            <option>Portable</option>
          </select>
        </div>

        <div class="uk-width-1-2">
          <label for="sof-chave-registro" class="uk-form-label required">Chave de registro</label>
          <input id="sof-chave-registro" type="text" class="uk-input" required v-model="info.sofChaveRegistro" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-3">
          <label for="sof-nivel-permissao" class="uk-form-label required">Nível de permissão</label>
          <select id="sof-nivel-permissao" class="uk-select" v-model="info.sofNivelPermissao" @change="updateDetalhes">
            <option>Administrador</option>
            <option>Usuário</option>
          </select>
        </div>

        <div class="uk-width-1-3">
          <label for="sof-remove-versao-anterior" class="uk-form-label required">Remove versão anterior</label>
          <select id="sof-remove-versao-anterior" class="uk-select" v-model="info.sofRemoveVersaoAnterior" @change="updateDetalhes">
            <option>Sim</option>
            <option>Não</option>
          </select>
        </div>

        <div class="uk-width-1-3">
          <label for="sof-req-reiniciar" class="uk-form-label required">Necessário reiniciar</label>
          <select id="sof-req-reiniciar" class="uk-select" v-model="info.sofReqReiniciar" @change="updateDetalhes">
            <option>Não</option>
            <option>Sim</option>
          </select>
        </div>
      </div><!-- .grid -->

      <hr>

      <h2 class="uk-h4 uk-margin-small">Pré-requisitos</h2>
      <div uk-grid>
        <div class="uk-width-1-2">
          <label for="sof-inclusos" class="uk-form-label">Pacotes inclusos</label>
          <input id="sof-inclusos" type="text" class="uk-input" v-model="info.sofInclusos" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-prereq" class="uk-form-label">Pré-requisitos</label>
          <input id="sof-prereq" type="text" class="uk-input" v-model="info.sofPreReq" @input="updateDetalhes" />
        </div>
      </div><!-- .grid -->

      <hr>

      <h2 class="uk-h4 uk-margin-small">Sistema Operacional</h2>
      <div uk-grid>
        <div class="uk-width-1-2">
          <label for="so-nome" class="uk-form-label required">Nome</label>
          <select id="so-nome" class="uk-select" v-model="info.soNome" @change="updateDetalhes">
            <option>Windows 10</option>
            <option>Windows 11</option>
            <option>MAC OS</option>
            <option>Linux Red Hat</option>
          </select>
        </div>

        <div class="uk-width-1-2">
          <label for="so-versao" class="uk-form-label required">Versão / Build</label>
          <input id="so-versao" type="text" class="uk-input" required v-model="info.soVersao" @input="updateDetalhes" />
        </div>
      </div><!-- .grid -->

      <hr>

      <h2 class="uk-h4 uk-margin-small">Finalização</h2>
      <div uk-grid>
        <div class="uk-width-1-2">
          <label for="equipamento-testado" class="uk-form-label required">Equipamento testado</label>
          <input id="equipamento-testado" type="text" class="uk-input" required v-model="info.equipamentoTestado" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="data-termino" class="uk-form-label required">Data término</label>
          <date-pick v-model="info.dataTermino" @input="updateDetalhes" :displayFormat="'DD/MM/YYYY'" :prevMonthCaption="'Anterior'" :nextMonthCaption="'Próximo'" :setTimeCaption="'Hora:'" :weekdays="['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom']" :months="['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembero', 'Outubro', 'Novembero', 'Dezembro']"> </date-pick>
        </div>

        <div class="uk-width-1-1">
          <label for="sof-doc-link" class="uk-form-label required">Link da documentação técnica</label>
          <input id="sof-doc-link" type="text" class="uk-input" placeholder="https://iconectados.sharepoint.com/sites/DocTecnicaSoftware/Documentos..." required v-model="info.sofDocLink" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-sccm-id" class="uk-form-label required">ID central de software</label>
          <input id="sof-sccm-id" type="text" class="uk-input" placeholder="ScopeId_XXX" required v-model="info.sofSccmId" @input="updateDetalhes" />
        </div>

        <div class="uk-width-1-2">
          <label for="sof-sccm-remove-versoes-anteriores" class="uk-form-label required">Removido versões anteriores da central</label>
          <select id="sof-sccm-remove-versoes-anteriores" class="uk-select" v-model="info.sofSccmRemoveVersoesAnteriores" @change="updateDetalhes">
            <option>Não</option>
            <option>Sim</option>
          </select>
        </div>

        <div class="uk-width-1-2 sccm-versoes-removidas dn">
          <div>
            <label for="sof-sccm-versoes-removidas" class="uk-form-label required">Quais</label>
            <input id="sof-sccm-versoes-removidas" type="text" class="uk-input" required v-model="info.sofSccmVersoesRemovidas" @input="updateDetalhes" />
          </div>
        </div>
      </div><!-- .grid -->

      <div class="homologa-info uk-margin-medium-top">
        <ul class="uk-tab" data-uk-tab="{connect:'#tipo-arquivo'}">
          <li><a href="#">Info.txt</a></li>
          <li><a href="#">Info.au3</a></li>
        </ul>

        <div id="tipo-arquivo" class="uk-switcher">
          <div class="tab-content1 uk-width-expand">
            <textarea id="sof-arquivo-info" class="uk-textarea" rows="22" style="height: auto" v-model="info.sofArquivoInfo" @input="updateDetalhes"></textarea>
          </div><!-- .tab-content1 -->

          <div class="tab-content2 uk-width-expand">
            <textarea id="sof-arquivo-au3" class="uk-textarea" rows="22" style="height: auto" v-model="info.sofArquivoAu3" @input="updateDetalhes"></textarea>
          </div><!-- .tab-content2 -->
        </div><!-- .uk-switcher -->
      </div>
    </div><!-- .homologacao -->

    <div class="uk-margin-top uk-text-right">
      <button id="limpar-campos" class="uk-button uk-button-primary" @click.prevent="resetState">Limpar</button>
      <button class="uk-button uk-button-primary uk-margin-small-left" @click.prevent="goTo('top')"><span uk-icon="icon:triangle-up"></span></button>
    </div>
  </div>
</template>

<script>

// Load menu
localStorage.setItem('layout', 'homologacao')

import Fraseologia from '~/plugins/fraseologia.js';
import DatePick from 'vue-date-pick';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    DatePick,
  },

  data() {
    return this.initialState();
  },

  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();
    Fraseologia.onPasteFocusNext();

    // Adiciona margem superior se não houver elemento nav
    if (document.querySelector('nav') === null) {
      document.querySelector('.main').style.marginTop = '32px';
    }

    // Data de início
    this.info.dataInicio = Fraseologia.today();
    this.info.dataInicioHtml = Fraseologia.todayHtml(this.info.dataInicio);

    // Storages
    this.loadStorages();

    // Checa funções de mudanças de elementos
    this.loadFuncoes();

    // Checa se foi removida versão do SCCM

    // Pega conteúdo dos arquivos
    this.info.sofArquivoInfo = this.getArquivoInfo();
    this.info.sofArquivoAu3 = this.getArquivoAu3();
  },
  methods: {
    initialState() {
      return {
        resumo: 'Informações do pacote',

        info: {
          // Solicitação
          sofSolicitacaoNumero: '',
          sofAmbiente: 'Itaú-Unibanco',
          sofStatusCertificacao: 'Certificado',
          sofCategoria: 'Corporativo',
          dataInicio: '',
          dataInicioHtml: '',
          dataTermino: '',
          dataTerminoHtml: '',

          // Licenciamento
          sofInfoLicenca: '',
          sofTipoLicenca: '',
          equipamentoTestado: '',
          sofRemoveVersaoAnterior: 'Sim',

          // Analista
          analistaNome: '',
          analistaEmail: '',
          revisorNome: '',

          // Solicitante
          solicitanteNome: '',
          solicitanteEmail: '',
          solicitanteFunc: '',
          solicitanteRacf: '',
          coordenacao: '',
          gerencia: '',

          // Solicitante adicional
          solicitanteAdicional: '',
          solicitanteAdicionalNome: '',
          solicitanteAdicionalEmail: '',
          solicitanteAdicionalFunc: '',
          solicitanteAdicionalRacf: '',

          // Responsável
          sofResponsavelNome: '',
          sofResponsavelEmail: '',
          sofResponsavelFunc: '',
          sofResponsavelRacf: '',

          // Grupo Aprovador
          sofGrupoAprovador: '',

          // Software
          sofNome: '',
          sofVersao: '',
          sofEdicao: '1.0',
          sofArquitetura: '64bits',
          sofDescricao: '',
          sofFabricanteNome: '',
          sofFabricanteSite: '',
          sofDisplayName: '',
          sofDisplayVersion: '',
          sofExeCaminho: '',
          sofExeNome: '',
          sofExeCaminhoCompleto: '',
          sofTamanhoSetup: '',
          sofTamanhoInstalado: '',
          sofTamanhoDisco: '',
          sofInstalacaoComando: '',
          sofInstalacaoParamentro: '',
          sofDesinstalacaoComando: '',
          sofDesinstalacaoParamentro: '',
          sofTipoInstalador: '',
          sofNivelPermissao: 'Administrador',
          sofChaveRegistro: '',

          // Pré-requisitos
          sofInclusos: 'Nenhum',
          sofPreReq: 'Nenhum',

          // Sistema Operacional
          soNome: 'Windows 10',
          soVersao: '20H2',

          // Repositório
          sofMapeamento: '',
          sofMapeamentoRepositorio: '',
          sofRepositorio: '',
          sofRepositorioExecutavel: '',
          sofReqReiniciar: 'Não',

          // Documentação
          sofDocLink: '',

          // Sccm
          sofSccmId: '',
          sofSccmLink: 'softwarecenter:SoftwareID=',
          sofSccmColecaoId: '',
          sofSccmRemoveVersoesAnteriores: 'Não',
          sofSccmVersoesRemovidas: 'Nenhuma',

          // Conteúdo dos arquivos
          sofArquivoInfo: '',
          sofArquivoAu3: '',
        },
      }
    },

    // Ir ao final e início da página
    goTo(location) {
      if (location == 'bottom') {
        window.scrollTo({ top: document.querySelector('.main').offsetHeight, behavior: 'smooth' });
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    },

    // Reseta todos os campos
    resetState() {
      // Guarda variáveis temporárias
      let analistaNomeTemp = this.info.analistaNome;
      let analistaEmailTemp = this.info.analistaEmail;
      let revisorNomeTemp = this.info.revisorNome;

      // Reseta campos valores iniciais
      Object.assign(this.$data, this.initialState());

      // Atribui variáveis temporárias
      this.info.analistaNome = analistaNomeTemp;
      this.info.analistaEmail = analistaEmailTemp;
      this.info.revisorNome = revisorNomeTemp;
      this.info.sofArquivoInfo = this.getArquivoInfo();
      this.info.sofArquivoAu3 = this.getArquivoAu3();

      // Data de início
      this.info.dataInicio = Fraseologia.today();
      this.info.dataInicioHtml = Fraseologia.todayHtml(this.info.dataInicio);

      this.saveStorages();
    },

    loadFuncoes() {
      this.checkSccmVersoes();
    },

    adicionaSolicitanteAdicional(e) {
      let el = document.querySelector('.solicitante-adicional');

      if (e.target.checked) {
        el.classList.remove('dn');
        this.info.solicitanteAdicional = true;
      } else {
        el.classList.add('dn');
        this.info.solicitanteAdicional = false;
      }

      this.updateDetalhes();
    },

    clonaSolicitante(e) {
      if (e.target.checked) {
        this.info.sofResponsavelNome = this.info.solicitanteNome;
        this.info.sofResponsavelEmail = this.info.solicitanteEmail;
        this.info.sofResponsavelFunc = this.info.solicitanteFunc;
        this.info.sofResponsavelRacf = this.info.solicitanteRacf;
      }

      this.updateDetalhes();
    },

    getTamanhoDisco(sofTamanhoSetup, sofTamanhoInstalado) {
      let tamanhoDisco = '';

      if (sofTamanhoSetup !== '' && sofTamanhoInstalado !== '') {
        tamanhoDisco = (+sofTamanhoSetup) + (+sofTamanhoInstalado);
        tamanhoDisco = tamanhoDisco.toFixed(3);
      }

      return tamanhoDisco;
    },

    getCaminhoCompletoExe(sofExeCaminho, sofExeNome) {
      let caminho = '';

      if (sofExeCaminho !== '' && sofExeNome !== '') {
        caminho = `${sofExeCaminho}\\${sofExeNome}`;
      }

      return caminho;
    },

    getMapeamento(sofAmbiente, sofCategoria) {
      let mapeamento = '';
      let caminhoItau = '\\\\fswcorp\\cto\\SASM';
      let caminhoRede = '\\\\172.20.201.93\\golddisk\\Field Service JK\\SOFTWARES';

      if ((sofAmbiente === 'Itaú-Unibanco' || sofAmbiente === 'IBBA') && sofCategoria === 'Corporativo') {
        mapeamento = `${caminhoItau}\\SOFTWARE_CORPORATIVO`;
      } else if ((sofAmbiente === 'Itaú-Unibanco' || sofAmbiente === 'IBBA') && sofCategoria === 'Restrito') {
        mapeamento = `${caminhoItau}\\SOFTWARE_RESTRITO`;
      } else if ((sofAmbiente === 'Itaú-Unibanco' || sofAmbiente === 'IBBA') && sofCategoria === 'Licenciado') {
        mapeamento = `${caminhoItau}\\SOFTWARE_LICENCIADO`;
      } else if (sofAmbiente === 'Rede' && sofCategoria === 'Corporativo') {
        mapeamento = `${caminhoRede}\\CORPORATIVO`;
      } else if (sofAmbiente === 'Rede' && sofCategoria === 'Restrito') {
        mapeamento = `${caminhoRede}\\RESTRITO`;
      } else if (sofAmbiente === 'Rede' && sofCategoria === 'Licenciado') {
        mapeamento = `${caminhoRede}\\LICENCIADO`;
      }

      return mapeamento;
    },

    getMapeamentoRepositorio(sofNome, sofVersao) {
      let repositorio = '';
      if (sofNome !== '' && sofVersao !== '') {
        repositorio = `N:\\${sofNome}\\${sofVersao}\\Instalador`;
      }

      return repositorio;
    },

    getRepositorio(sofMapeamento, sofNome, sofVersao) {
      let repositorio = '';

      if (sofMapeamento !== '' && sofNome !== '' && sofVersao !== '') {
        repositorio = `${sofMapeamento}\\${sofNome}\\${sofVersao}\\Instalador`;
      }

      return repositorio;
    },

    getRepositorioExecutavel(sofMapeamento, sofNome, sofVersao) {
      let repositorioExecutavel = '';

      if (sofMapeamento !== '' && sofNome !== '' && sofVersao !== '') {
        repositorioExecutavel = `${sofMapeamento}\\${sofNome}\\${sofVersao}\\Instalador\\${sofNome} ${sofVersao}.exe`;
      }

      return repositorioExecutavel;
    },

    getSccmLink(sofSccmId) {
      let sofSccmLink = '';

      if (sofSccmId) {
        sofSccmLink = `softwarecenter:SoftwareID=${sofSccmId}`;
      } else {
        sofSccmLink = ''
      }

      return sofSccmLink;
    },

    getSolicitanteAdicional(solicitanteAdicional) {
      if (solicitanteAdicional) {
        return this.info.solicitanteAdicional = `

# Solicitante adicional
solicitante_adicional_nome: ${this.info.solicitanteAdicionalNome}
solicitante_adicional_email: ${this.info.solicitanteAdicionalEmail}
solicitante_adicional_funcional: ${this.info.solicitanteAdicionalFunc}
solicitante_adicional_racf: ${this.info.solicitanteAdicionalRacf}`;
      } else {
        return this.info.solicitanteAdicional = '';
      }
    },

    checkSccmVersoes() {
      let el = document.querySelector('.sccm-versoes-removidas');

      if (this.info.sofSccmRemoveVersoesAnteriores === 'Sim') {
        el.classList.remove('dn');
        this.info.sofSccmVersoesRemovidas = ''
      } else {
        el.classList.add('dn');
        this.info.sofSccmVersoesRemovidas = 'Nenhuma'
      }
    },

    convertArquivoInfoToAu3(content) {
      let reSearch = /#/g;
      let reReplace = ';';
      content = content.replace(reSearch, reReplace);

      reSearch = /(.*)(?:: )(.*)/g;
      reReplace = "$$info.Add('$1', '$2')";
      content = content.replace(reSearch, reReplace);

      reSearch = /; Dados gerais/g;
      reReplace = "; Cria dicionário\n$info = ObjCreate('Scripting.Dictionary')\n\n; Dados gerais"
      content = content.replace(reSearch, reReplace);

      return content;
    },

    updateDetalhes() {
      // Une variáveis
      this.info.solicitanteAdicional = this.getSolicitanteAdicional(this.info.solicitanteAdicional);
      this.info.sofTamanhoDisco = this.getTamanhoDisco(this.info.sofTamanhoSetup, this.info.sofTamanhoInstalado);
      this.info.sofExeCaminhoCompleto = this.getCaminhoCompletoExe(this.info.sofExeCaminho, this.info.sofExeNome);
      this.info.sofMapeamento = this.getMapeamento(this.info.sofAmbiente, this.info.sofCategoria);
      this.info.sofMapeamentoRepositorio = this.getMapeamentoRepositorio(this.info.sofNome, this.info.sofVersao);
      this.info.sofRepositorio = this.getRepositorio(this.info.sofMapeamento, this.info.sofNome, this.info.sofVersao);
      this.info.sofRepositorioExecutavel = this.getRepositorioExecutavel(this.info.sofMapeamento, this.info.sofNome, this.info.sofVersao);
      this.info.sofSccmLink = this.getSccmLink(this.info.sofSccmId);

      // Datas
      if (this.info.dataInicio) {
        this.info.dataInicioHtml = Fraseologia.todayHtml(this.info.dataInicio);
      } else {
        this.info.dataInicioHtml = '';
      }

      if (this.info.dataTermino) {
        this.info.dataTerminoHtml = Fraseologia.todayHtml(this.info.dataTermino);
      } else {
        this.info.dataTerminoHtml = '';
      }

      // Check em todas as funções de mudança de elemento
      this.loadFuncoes();

      // Save storages
      this.saveStorages();

      // Pega conteúdo dos arquivos
      this.info.sofArquivoInfo = this.getArquivoInfo();
      this.info.sofArquivoAu3 = this.getArquivoAu3();
    },

    loadStorages() {
      for (let key in this.info) {
        if (localStorage.getItem(key)) { this.info[key] = localStorage.getItem(key); }
      }
    },

    saveStorages() {
      for (let key in this.info) {
        localStorage.setItem(key, this.info[key]);
      }
    },

    getArquivoInfo() {
      let arquivoInfoContent = `# ------------------------------------------------------------------------------
# Informações do pacote
# ------------------------------------------------------------------------------

# Solicitação
solicitacao_numero: ${this.info.sofSolicitacaoNumero}
ambiente: ${this.info.sofAmbiente}
status_certificacao: ${this.info.sofStatusCertificacao}
sof_categoria: ${this.info.sofCategoria}
sof_tipo_licenca: ${this.info.sofTipoLicenca}
data_inicio: ${this.info.dataInicioHtml}
data_termino: ${this.info.dataTerminoHtml}
equipamento_testado: ${this.info.equipamentoTestado}

# Analista
analista_nome: ${this.info.analistaNome}
analista_email: ${this.info.analistaEmail}
revisor_nome: ${this.info.revisorNome}

# Solicitante
solicitante_nome: ${this.info.solicitanteNome}
solicitante_email: ${this.info.solicitanteEmail}
solicitante_funcional: ${this.info.solicitanteFunc}
solicitante_racf: ${this.info.solicitanteRacf}
coordenacao: ${this.info.coordenacao}
gerencia: ${this.info.gerencia} ${this.info.solicitanteAdicional}

# Responsável
sof_responsavel_nome: ${this.info.sofResponsavelNome}
sof_responsavel_email: ${this.info.sofResponsavelEmail}
sof_responsavel_funcional: ${this.info.sofResponsavelFunc}
sof_responsavel_racf: ${this.info.sofResponsavelRacf}

# Grupo aprovador
sof_grupo_aprovador: ${this.info.sofGrupoAprovador}

# Software
sof_nome: ${this.info.sofNome}
sof_versao: ${this.info.sofVersao}
sof_edicao: ${this.info.sofEdicao}
sof_arquitetura: ${this.info.sofArquitetura}
sof_descricao: ${this.info.sofDescricao}
sof_fabricante_nome: ${this.info.sofFabricanteNome}
sof_fabricante_site: ${this.info.sofFabricanteSite}
sof_display_name: ${this.info.sofDisplayName}
sof_display_version: ${this.info.sofDisplayVersion}
sof_tamanho_setup: ${this.info.sofTamanhoSetup}
sof_tamanho_instalado: ${this.info.sofTamanhoInstalado}
sof_tamanho_disco: ${this.info.sofTamanhoDisco}
sof_executavel_caminho: ${this.info.sofExeCaminho}
sof_executavel_nome: ${this.info.sofExeNome}
sof_executavel_caminho_completo: ${this.info.sofExeCaminhoCompleto}
sof_instalacao_comando: ${this.info.sofInstalacaoComando}
sof_instalacao_parametro: ${this.info.sofInstalacaoParamentro}
sof_desinstalacao_comando: ${this.info.sofDesinstalacaoComando}
sof_desinstalacao_parametro: ${this.info.sofDesinstalacaoParamentro}
sof_tipo_instalador: ${this.info.sofTipoInstalador}
sof_remove_versao_anterior: ${this.info.sofRemoveVersaoAnterior}
sof_necessario_reiniciar: ${this.info.sofReqReiniciar}
sof_nivel_permissao: ${this.info.sofNivelPermissao}
sof_chave_registro: ${this.info.sofChaveRegistro}

# Inclusos e pré-requisitos
sof_inclusos: ${this.info.sofInclusos}
sof_pre_requisitos: ${this.info.sofPreReq}

# Sistema Operacional
so_nome: ${this.info.soNome}
so_versao: ${this.info.soVersao}

# Repositório
sof_repositorio: ${this.info.sofRepositorio}
sof_repositorio_executavel: ${this.info.sofRepositorioExecutavel}
sof_map: ${this.info.sofMapeamento}
sof_map_repositorio: ${this.info.sofMapeamentoRepositorio}

# Documentação
sof_doc_link: ${this.info.sofDocLink}

# SCCM
sof_sccm_id: ${this.info.sofSccmId}
sof_sccm_link: ${this.info.sofSccmLink}
sof_sccm_colecao_id: ${this.info.sofSccmColecaoId}
sof_sccm_remove_versoes_anteriores: ${this.info.sofSccmRemoveVersoesAnteriores}
sof_sccm_versoes_removidas: ${this.info.sofSccmVersoesRemovidas}`;

      return arquivoInfoContent;
    },

    getArquivoAu3() {
      let arquivoInfoContent = `;~ -----------------------------------------------------------------------------
;~ Informações do pacote
;~ -----------------------------------------------------------------------------

$analista = '${this.info.analistaNome}'
$data = '${this.info.dataInicioHtml}'
$software_nome = '${this.info.sofNome}'
$software_versao = '${this.info.sofVersao}'
$software_descricao = '${this.info.sofDescricao}'
$displayname = '${this.info.sofDisplayName}'
$displayversion = '${this.info.sofDisplayVersion}'

;~ Tamanhos
$tamanho_pasta_temp = '${this.info.sofTamanhoSetup}'
$tamanho_pasta_software = '${this.info.sofTamanhoInstalado}'

;~ Caminho e executável
$caminho_pasta_software = '${this.info.sofExeCaminho}'
$nome_executavel = '${this.info.sofExeNome}'
$caminho_executavel = $caminho_pasta_software & '\\' & $nome_executavel

;~ Comandos e parâmetros de instalação e remoção
$setup_install = '${this.info.sofInstalacaoComando}'
$parametro_install = '${this.info.sofInstalacaoParamentro}'
$comando_remocao = '${this.info.sofDesinstalacaoComando}'
$parametro_remocao = '${this.info.sofDesinstalacaoParamentro}'

;~ Softwares inclusos e pré-requisitos
$software_inclusos = '${this.info.sofInclusos}'
$software_pre_requisitos = '${this.info.sofPreReq}'`;

      return arquivoInfoContent;
    },
  },
};
</script>
