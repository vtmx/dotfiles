<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="armazena-credenciais" class="uk-form-label required">Armazena credenciais</label>
        <select id="armazena-credenciais" class="uk-select" v-model="armazenaCredenciais" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="automacao-ou-robo" class="uk-form-label required">Cria de automações de tarefas/robôs</label>
        <select id="automacao-ou-robo" class="uk-select" v-model="automacaoOuRobo" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="captura-trafego-network" class="uk-form-label required">Realiza captura de tráfego web/network</label>
        <select id="captura-trafego-network" class="uk-select" v-model="capturaTrafegoNetwork" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="captura-ou-gravacao-tela" class="uk-form-label required">Realiza a captura ou gravação de telas</label>
        <select id="captura-ou-gravacao-tela" class="uk-select" v-model="capturaTela" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="permite-acesso-remoto" class="uk-form-label required">Permite acesso remoto (SSH, RDP)</label>
        <select id="permite-acesso-remoto" class="uk-select" v-model="permiteAcessoRemoto" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="transferencia-arquivos" class="uk-form-label required">Transferência de arquivos (SFTP, FTP, HTTPS)</label>
        <select id="transferencia-arquivos" class="uk-select" v-model="transferenciaArquivos" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>
    </div> <!-- .uk-grid -->

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Análise de Risco de Plugin',
      status: 'Direcionado',
      detalhes: '',
      // ---
      armazenaCredenciais: 'Não',
      automacaoOuRobo: 'Não',
      capturaTrafegoNetwork: 'Não',
      capturaTela: 'Não',
      permiteAcessoRemoto: 'Não',
      transferenciaArquivos: 'Não',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    this.updateDetalhes();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `Checklist de verificação de funcionalidades do Plugin     

Avaliado pela documentação: Sim
Instalado e testado em laboratório: Sim

a) Função de armazenamento de credenciais (Cofre de Senhas): ${this.armazenaCredenciais}
b) Cria de automações de tarefas/robôs na estação de trabalho: ${this.automacaoOuRobo}
c) Realiza a captura de tráfego web/network: ${this.capturaTrafegoNetwork}
d) Realiza a captura ou gravação de telas: ${this.capturaTela}
e) Permite/realiza o acesso remoto (SSH, RDP): ${this.permiteAcessoRemoto}
f) Transferência de arquivos (independente do protocolo: SFTP, FTP, HTTPS, etc): ${this.transferenciaArquivos}

Obs: Se qualquer uma das respostas foi positiva, é necessário submeter o produto ao time de Análise de Risco.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>