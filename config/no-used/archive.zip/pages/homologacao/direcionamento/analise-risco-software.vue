<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="cria-banco-de-dados" class="uk-form-label required">Cria ou utiliza banco de dados local</label>
        <select id="cria-banco-de-dados" class="uk-select" v-model="criaBancoDeDados" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="cria-usuario-ou-grupo" class="uk-form-label required">Cria usuário ou grupo local</label>
        <select id="cria-usuario-ou-grupo" class="uk-select" v-model="criaUsuarioOuGrupo" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="necessario-admin" class="uk-form-label required">Necessário usuário administrador</label>
        <select id="necessario-admin" class="uk-select" v-model="necessarioAdmin" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="uso-em-servidores" class="uk-form-label required">Finalidade para uso em servidores</label>
        <select id="uso-em-servidores" class="uk-select" v-model="usoEmServidores" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="automacao-ou-robo" class="uk-form-label required">Cria de automações de tarefas/robôs</label>
        <select id="automacao-ou-robo" class="uk-select" v-model="automacaoOuRobo" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="captura-ou-gravacao-tela" class="uk-form-label required">Realiza a captura ou gravação de telas</label>
        <select id="captura-ou-gravacao-tela" class="uk-select" v-model="capturaTela" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="captura-trafego-network" class="uk-form-label required">Realiza captura de tráfego web/network</label>
        <select id="captura-trafego-network" class="uk-select" v-model="capturaTrafegoNetwork" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="portas-nao-habilitadas-proxy" class="uk-form-label required">Utiliza portas não habilitadas no proxy</label>
        <select id="portas-nao-habilitadas-proxy" class="uk-select" v-model="portasNaoHabilitadasProxy" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="permite-acesso-remoto" class="uk-form-label required">Permite acesso remoto (SSH, RDP)</label>
        <select id="permite-acesso-remoto" class="uk-select" v-model="permiteAcessoRemoto" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="transferencia-arquivos" class="uk-form-label required">Transferência de arquivos (SFTP, FTP, HTTPS)</label>
        <select id="transferencia-arquivos" class="uk-select" v-model="transferenciaArquivos" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="conexao-vpn" class="uk-form-label required">Realiza conexão VPN</label>
        <select id="conexao-vpn" class="uk-select" v-model="conexaoVpn" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
          <option>Não avaliado</option>
        </select>
      </div>
    </div> <!-- .uk-grid -->

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Análise de Risco de Software',
      status: 'Direcionado',
      detalhes: '',
      // ---
      criaBancoDeDados: 'Não',
      criaUsuarioOuGrupo: 'Não',
      necessarioAdmin: 'Não',
      usoEmServidores: 'Não',
      automacaoOuRobo: 'Não',
      capturaTela: 'Não',
      capturaTrafegoNetwork: 'Não',
      portasNaoHabilitadasProxy: 'Não',
      permiteAcessoRemoto: 'Não',
      transferenciaArquivos: 'Não',
      conexaoVpn: 'Não',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    this.updateDetalhes();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `Checklist de verificação de funcionalidades do Software     

Avaliado pela documentação: Sim
Instalado e testado em laboratório: Sim

a) Software cria/utiliza banco de dados local: ${this.criaBancoDeDados}
b) Realiza criação de usuário/grupo: ${this.criaUsuarioOuGrupo}
c) Necessidade de usuário administrador para ser executado: ${this.necessarioAdmin}
d) Produto com finalidade para uso em Servidores: ${this.usoEmServidores}
e) Cria de automações de tarefas/robôs na estação de trabalho: ${this.automacaoOuRobo}
f) Realiza a captura ou gravação de telas: ${this.capturaTela}
g) Realiza captura de tráfego web/network: ${this.capturaTrafegoNetwork}
h) Realiza conexão com a internet em portas não habilitadas no proxy: ${this.portasNaoHabilitadasProxy}
i) Permite/realiza o acesso remoto (SSH, RDP): ${this.permiteAcessoRemoto}
j) Transferência de arquivos (independente do protocolo: SFTP, FTP, HTTPS, etc): ${this.transferenciaArquivos}
k) Realiza/permite estabelecer uma conexão VPN: ${this.conexaoVpn}

Obs: Se qualquer uma das respostas foi positiva, é necessário submeter o produto ao time de Análise de Risco.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>