<template>
  <div>
    {{ titulo }}
  </div>
</template>

<script>
// Load menu
localStorage.setItem('layout', 'telecom')

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.titulo}`,
    };
  },
  data() {
    return {
      titulo: 'Telecom'
    }
  }
};
</script>
