<template>
  <div>
    {{ titulo }}
  </div>
</template>

<script>
// Load menu
localStorage.setItem('layout', 'atendimento')

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.titulo}`,
    };
  },
  data() {
    return {
      titulo: 'Atendimento'
    }
  }
};
</script>
