<template>
  <ul class="uk-navbar-nav">
    <li>
      <n-link to="/homologacao/inicio/info">Informações</n-link>
    </li>
    <li>
      <a href="#">Andamento</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/homologacao/andamento/pedido-de-acordo">Pedido de acordo</n-link>
          </li>
          <li>
            <n-link to="/homologacao/andamento/pedido-de-descontinuacao">Pedido de descontinuação</n-link>
          </li>
        </ul>
      </div>
    </li>

    <li>
      <a href="#">Espera</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/homologacao/espera/resposta-de-acordo">Resposta de acordo</n-link>
          </li>
          <li>
            <n-link to="/homologacao/espera/resposta-mudanca-responsavel">Resposta de mudança de dono</n-link>
          </li>
          <li>
            <n-link to="/homologacao/espera/resposta-teste">Resposta de teste</n-link>
          </li>
        </ul>
      </div>
    </li>

    <li>
      <a href="#">Direcionamento</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/homologacao/direcionamento/analise-risco-software">Análise risco software</n-link>
          </li>
          <li>
            <n-link to="/homologacao/direcionamento/analise-risco-plugin">Análise risco plugin</n-link>
          </li>
        </ul>
      </div>
    </li>

    <li>
      <a href="#">Fechamento</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/homologacao/fechamento/desenvolvimento">Desenvolvimento</n-link>
          </li>
          <li>
            <n-link to="/homologacao/fechamento/validacao">Validação</n-link>
          </li>
          <li>
            <n-link to="/homologacao/fechamento/publicacao">Publicação</n-link>
          </li>
        </ul>
      </div>
    </li>

    <li>
      <a href="#">Cancelamento</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/homologacao/cancelamento/falta-de-informacoes">Falta de informações</n-link>
          </li>
          <li>
            <n-link to="/homologacao/cancelamento/software-existe">Software já existe</n-link>
          </li>
          <li>
            <n-link to="/homologacao/cancelamento/falta-de-resposta-responsavel">Falta de resposta do responsável</n-link>
          </li>
          <li>
            <n-link to="/homologacao/cancelamento/compra-licenca">Compra de licença</n-link>
          </li>
          <li>
            <n-link to="/homologacao/cancelamento/extensao-de-navegador">Extensão de navegador</n-link>
          </li>
          <li>
            <n-link to="/homologacao/cancelamento/hardware">Hardware</n-link>
          </li>
        </ul>
      </div>
    </li>
  </ul>
</template>