<template>
  <nav class="uk-navbar-container uk-margin-bottom">
    <div class="uk-container uk-container-small">
      <nav class="uk-navbar" uk-navbar>
        <AppLogo />
        <MenuHomologacao />
      </nav>
    </div>
  </nav>
</template>

<script>
import AppLogo from '~/components/app-logo.vue';
import MenuHomologacao from '~/components/homologacao-menu.vue';

export default {
  components: {
    AppLogo,
    MenuHomologacao,
  },
};
</script>