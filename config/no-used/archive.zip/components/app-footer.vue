<template>
	<footer class="footer">
		<div class="uk-container uk-container-small uk-padding-small">
			<div class="uk-child-width-expand@s" uk-grid>
				<div class="uk-text-left">Desenvolvido por <n-link to="/autor">Vitor Melo</n-link></div>
				<div class="uk-text-right">Versão <n-link to="/changelog">2.7.2</n-link></div>
			</div>
		</div>
	</footer>
</div>
