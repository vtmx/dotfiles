<template>
  <ul class="uk-navbar-nav">
    <li>
      <a href="#">Início</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/licenca/inicio/eula">EULA</n-link>
          </li>
        </ul>
      </div>
    </li>

    <li>
      <a href="#">Espera</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/licenca/espera/sem-acesso-email-externo">Sem acesso email externo</n-link>
          </li>
          <li>
            <n-link to="/licenca/espera/aguardando-recebimento-licenca">Aguardando recebimento da licença</n-link>
          </li>
        </ul>
      </div>
    </li>

    <li>
      <a href="#">Fechamento</a>
      <div class="uk-navbar-dropdown" uk-dropdown="animation: uk-animation-fade; duration: 100; delay-hide: 100">
        <ul class="uk-nav uk-navbar-dropdown-nav">
          <li>
            <n-link to="/licenca/fechamento/autorizacao-instalacao">Autorização de instalação</n-link>
          </li>
        </ul>
      </div>
    </li>
  </ul>
</template>