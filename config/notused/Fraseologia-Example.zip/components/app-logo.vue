<template>
  <n-link to="/" class="uk-navbar-item uk-logo" title="Início">
    <span class="logo">Fraseologia</span>
  </n-link>
</template>
