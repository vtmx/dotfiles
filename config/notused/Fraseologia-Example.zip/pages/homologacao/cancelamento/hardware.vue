<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Hardware',
      status: 'Cancelamento',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `A solicitação para homologação hardware corporativo é feita através do link:
https://itau.service-now.com/tech?id=sc_cat_item&sys_id=adab52161b1e9c100aff86afe54bcb24&sysparm_category=f11ebdf4db7fc490d5c087b3049619ce

A equipe de homologação de hardware só homologa ativos disponibilizados pelo banco.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>