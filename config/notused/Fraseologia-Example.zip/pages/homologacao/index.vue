<template>
  <div>
    {{ titulo }}
  </div>
</template>

<script>
// Load menu
localStorage.setItem('layout', 'homologacao')

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.titulo}`,
    };
  },
  data() {
    return {
      titulo: 'Homologação'
    }
  }
};
</script>
