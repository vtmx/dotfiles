<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Sem acesso a e-mail externo',
      status: 'Em espera',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = 'Verificamos que o usuário não possui acesso ao e-mail externo. Foi realizado a orientação para conseguir o acesso e iremos deixar o chamado em espera até o retorno do usuário.';
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>