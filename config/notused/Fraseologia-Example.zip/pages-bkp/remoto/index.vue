<template>
  <div>
    {{ titulo }}
  </div>
</template>

<script>
// Load menu
localStorage.setItem('layout', 'remoto')

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.titulo}`,
    };
  },
  data() {
    return {
      titulo: 'Remoto'
    }
  }
};
</script>
