<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-3">
        <label for="ritm" class="required">RITM</label>
        <input id="ritm" type="text" class="uk-input" required v-model="ritm" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="sof-nome" class="required">Software</label>
        <input id="sof-nome" type="text" class="uk-input" required v-model="sofNome" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="sof-versao" class="required">Versão</label>
        <input id="sof-versao" type="text" class="uk-input" required v-model="sofVersao" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="solicitante" class="required">Solicitante</label>
        <input id="solicitante" type="text" class="uk-input" required v-model="solicitante" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="email-solicitante" class="required">Email solicitante</label>
        <input id="email-solicitante" type="email" class="uk-input" required v-model="emailSolicitante" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="responsavel">Responsável</label>
        <input id="responsavel" type="text" class="uk-input" v-model="responsavel" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="email-responsavel" class="required">Email responsável</label>
        <input id="email-responsavel" type="email" class="uk-input" required v-model="emailResponsavel" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="novo-responsavel">Novo responsável</label>
        <input id="novo-responsavel" type="text" class="uk-input" v-model="novoResponsavel" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="email-novo-responsavel" class="required">Email novo responsável</label>
        <input id="email-novo-responsavel" type="email" class="uk-input" required v-model="emailNovoResponsavel" @input="updateDetalhes" />
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Resposta de Mudança de Responsabilidade',
      status: 'Em espera',
      detalhes: '',
      // ---
      ritm: '',
      sofNome: '',
      sofVersao: '',
      solicitante: '',
      emailSolicitante: '',
      responsavel: '',
      emailResponsavel: '',
      novoResponsavel: '',
      emailNovoResponsavel: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();
    Fraseologia.onPasteFocusNext();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `${this.emailResponsavel}
${this.emailSolicitante}
${this.emailNovoResponsavel}

${this.ritm} - ${this.sofNome} ${this.sofVersao} - Solicitação de De Acordo

Recebemos o pedido de homologação do ${this.sofNome} ${this.sofVersao} e gostaríamos de solicitar seu De Acordo para homologar essa nova versão.
O solicitante ${this.solicitante} em cópia, indicou como responsável ${this.novoResponsavel}, caso você não queira mais ser o responsável pelo software, nos informe respondendo esse e-mail, que a atribuição de responsabilidade será alterada.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>
