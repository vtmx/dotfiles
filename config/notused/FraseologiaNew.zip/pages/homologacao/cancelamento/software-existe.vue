<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Software já existe',
      status: 'Cancelamento',
      detalhes: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `O software já foi homologado.

Solicite a instalação através do link:
https://itau.service-now.com/tech?id=sc_cat_item&sys_id=f84039ae1b595050c39097d01b4bcb59

Caso seu problema seja na central de software, vá até o chat da Íris no link abaixo e selecione a opção: Como Solucionar Erro ao Abrir a Central de Software?
https://itau.service-now.com/tech`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>