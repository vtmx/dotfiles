<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>
    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Extensão de Navegador',
      status: 'Cancelamento',
      detalhes: '',
      // ---
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.updateDetalhes();
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `Certificação de extensão para navegador de internet não é atendido por nossa área.
Para que possa usar esse plug-in, deve solicitar uma análise risco, para que ela seja liberada via servidor e a instalação seja permitida.

Link para abertura da solicitação correta: https://confluencecorp.ctsp.prod.cloud.ihf/pages/viewpage.action?pageId=206307561

O seu chamado de certificação será cancelado.`;
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>