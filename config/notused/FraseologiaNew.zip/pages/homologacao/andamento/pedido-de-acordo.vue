<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-3">
        <label for="ritm" class="required">RITM</label>
        <input id="ritm" type="text" class="uk-input" required v-model="ritm" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="email-solicitante" class="required">Email solicitante</label>
        <input id="email-solicitante" type="text" class="uk-input" required v-model="emailSolicitante" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="responsavel">Responsável</label>
        <input id="responsavel" type="text" class="uk-input" v-model="responsavel" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="sof-nome" class="required">Nome do software</label>
        <input id="sof-nome" type="text" class="uk-input" required v-model="sofNome" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="sofVersao" class="required">Versão</label>
        <input id="sof-versao" type="text" class="uk-input" required v-model="sofVersao" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="terceiro" class="uk-form-label required">Solicitante é terceiro</label>
        <select id="terceiro" class="uk-select" v-model="terceiro" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
        </select>
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Pedido de acordo',
      status: 'Em andamento',
      detalhes: '',
      // ---
      emailSolicitante: '',
      terceiro: 'Não',
      ritm: '',
      responsavel: '',
      sofNome: '',
      sofVersao: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();
    Fraseologia.onPasteFocusNext();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {
      let conteudoTerceiro = ''
      let conteudoResponsavel = ''

      if (this.responsavel) {
        conteudoResponsavel = `do atual responsável do software: \n${this.responsavel}`;
      } else {
        conteudoResponsavel = `por quem será o responsável do software.`;
      }

      if (this.terceiro === 'Sim') {
        conteudoTerceiro = `\n\nTambém é necessário indicar um funcionário Itaú para ser o solicitante principal da requisição.`;
      }

      this.detalhes = `${this.emailSolicitante}
${this.ritm} - ${this.sofNome} ${this.sofVersao} - Pedido de De Acordo
Para prosseguirmos com a certificação do software será necessário um e-mail com o De Acordo ${conteudoResponsavel}${conteudoTerceiro}

Caso não houver resposta em dois dias, a requisição ${this.ritm} poderá ser cancelada.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>