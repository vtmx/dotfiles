<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="ritm" class="required">RITM</label>
        <input id="ritm" type="text" class="uk-input" required v-model="ritm" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="email-responsavel" class="required">Email responsável</label>
        <input id="email-responsavel" type="text" class="uk-input" required v-model="emailResponsavel" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="sof-nome" class="required">Nome do software</label>
        <input id="sof-nome" type="text" class="uk-input" required v-model="sofNome" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="sofVersao" class="required">Versão</label>
        <input id="sof-versao" type="text" class="uk-input" required v-model="sofVersao" @input="updateDetalhes" />
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Pedido de descontinuação',
      status: 'Em andamento',
      detalhes: '',
      // ---
      ritm: '',
      responsavel: '',
      emailResponsavel: '',
      sofNome: '',
      sofVersao: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();
    Fraseologia.onPasteFocusNext();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {
      this.detalhes = `${this.emailResponsavel}
Solicitamos o seu De Acordo para descontinuar o ${this.sofNome} versões anteiores à versão mais recente ${this.sofVersao} que está sendo homologada na ${this.ritm}.
As versões anteriores serão descontinuadas após o encerramento dos testes, tarefa de validação e publicação da versão atual.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>