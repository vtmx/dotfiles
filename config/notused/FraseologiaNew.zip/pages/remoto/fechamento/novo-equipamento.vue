<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="so" class="uk-form-label required">Sistema Operacional</label>
        <select id="so" class="uk-select" v-model="so" @change="updateDetalhes">
          <option>Windows 10</option>
          <option>Windows 11</option>
          <option>Mac</option>
          <option>Linux</option>
        </select>
      </div>

      <div class="uk-width-1-2">
        <label for="acao" class="uk-form-label required">Ação</label>
        <input id="acao" type="text" class="uk-input" required v-model="acao" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-1">
        <label for="solucao" class="uk-form-label required">Solução</label>
        <input id="solucao" type="text" class="uk-input" required v-model="solucao" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="equipamento-novo" class="uk-form-label required">Equipamento novo</label>
        <input id="equipamento-novo" type="text" class="uk-input" required v-model="equipamentoNovo" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="equipamento-antigo" class="uk-form-label required">Equipamento antigo</label>
        <input id="equipamento-antigo" type="text" class="uk-input" required v-model="equipamentoAntigo" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="ritm" class="uk-form-label required">RITM</label>
        <input id="ritm" type="text" class="uk-input" required v-model="ritm" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="termo-assinado" class="uk-form-label required">Termo assinado</label>
        <select id="termo-assinado" class="uk-select" v-model="termoAssinado" @change="updateDetalhes">
          <option>Sim</option>
          <option>Não</option>
        </select>
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Novo equipamento',
      status: 'Resolvido',
      detalhes: '',
      // ---
      so: 'Windows 10',
      acao: '',
      solucao: '',
      equipamentoNovo: '',
      equipamentoAntigo: '',
      termoAssinado: 'Sim',
      ritm: ''
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.detalhes = `Sistema operacional:
Ação: ${this.acao}
Solução: ${this.solucao}:
Equipamento novo: ${this.equipamentoNovo}
Equipamento antigo: ${this.equipamentoAntigo}
Termo assinado: ${this.termoAssinado}
RITM:${this.ritm} `

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.$store.commit('updateDetalhes', this.detalhes);
  },
  methods: {
    updateDetalhes() {

      this.detalhes = `Sistema operacional: ${this.so}
Ação: ${this.acao}
Solução: ${this.solucao}:
Equipamento novo: ${this.equipamentoNovo}
Equipamento antigo: ${this.equipamentoAntigo}
Termo assinado: ${this.termoAssinado}
RITM:${this.ritm} `

      this.$store.commit('updateStatus', this.status);
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>
