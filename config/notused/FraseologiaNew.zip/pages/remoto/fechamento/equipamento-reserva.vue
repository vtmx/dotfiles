<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="nome-colab" class="uk-form-label required">Nome do colaborador</label>
        <input id="nome-colab" type="text" class="uk-input" required v-model="nomeColab" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="telefone" class="uk-form-label">Telefone</label>
        <input id="telefone" type="text" class="uk-input" v-model="telefone" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="endereco" class="uk-form-label required">Endereço completo</label>
        <input id="endereco" type="text" class="uk-input" required v-model="endereco" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="cep" class="uk-form-label required">CEP</label>
        <input id="cep" type="text" class="uk-input" required v-model="cep" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="cidade" class="uk-form-label required">Cidade</label>
        <input id="cidade" type="text" class="uk-input" required v-model="cidade" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="cpf" class="uk-form-label required">CPF</label>
        <input id="cpf" type="text" class="uk-input" required v-model="cpf" @input="updateDetalhes" />
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'Equipamento reserva',
      status: 'Resolvido',
      detalhes: '',
      // ---
      nomeColab: '',
      telefone: '',
      endereco: '',
      cep: '',
      cidade: '',
      cpf: ''
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();

    this.detalhes = `Equipamento substituído pelo time de Regionais. Necessário reversa da máquina danificada
Nome do colaborador: ${this.nomeColab} 
Telefone: ${this.telefone}
Endereço completo: ${this.endereco}
Cep: ${this.cep}
Cidade: ${this.cidade}
CPF: ${this.cpf}`

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
    this.$store.commit('updateDetalhes', this.detalhes);
  },
  methods: {
    updateDetalhes() {

      this.detalhes = `Equipamento substituído pelo time de Regionais. Necessário reversa da máquina danificada
Nome do colaborador: ${this.nomeColab} 
Telefone: ${this.telefone}
Endereço completo: ${this.endereco}
Cep: ${this.cep}
Cidade: ${this.cidade}
CPF: ${this.cpf}`

      this.$store.commit('updateStatus', this.status);
      this.$store.commit('updateDetalhes', this.detalhes);
    },
  },
};
</script>
