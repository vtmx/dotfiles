<template>
  <div>
    <app-header />

    <main class="main uk-container uk-container-small uk-card uk-margin-large-bottom">
      <h1 class="uk-h4 uk-text-uppercase">Áreas</h1>

      <div class="uk-child-width-1-3@m uk-grid-small uk-grid-match" uk-grid>
        <div>
          <n-link to="#" class="uk-button uk-button-default" @click.native="updateLayout('atendimento', '/atendimento/inicio/chat')">Atendimento</n-link>
        </div>
        <div>
          <n-link to="#" class="uk-button uk-button-default" @click.native="updateLayout('remoto', '/geral/inicio/atendimento')">Remoto</n-link>
        </div>
        <div>
          <n-link to="#" class="uk-button uk-button-default" @click.native="updateLayout('vctp', '/geral/inicio/atendimento')">VCTP</n-link>
        </div>
      </div>
    </main>

    <app-footer />
  </div>
</template>

<script>
import AppHeader from '~/components/app-header.vue';
import AppFooter from '~/components/app-footer.vue';

// localStorage.setItem('layout', 'homologacao')
export default {
  components: {
    AppHeader,
    AppFooter,
  },
  methods: {
    updateLayout(layout, page) {
      localStorage.layout = layout;
      this.$store.commit('updateLayout', layout);
      this.$router.push(page)
    },
  },
};
</script>
