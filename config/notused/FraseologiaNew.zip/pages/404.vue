
<script>
import AppHeader from '~/components/app-header.vue';
import AppFooter from '~/components/app-footer.vue';

export default {
  layout: 'error',
  components: {
    AppHeader,
    AppFooter,
  },
};
</script>
