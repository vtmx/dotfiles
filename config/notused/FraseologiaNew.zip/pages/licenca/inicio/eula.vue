<template>
  <div>
    <h1 class="uk-h4 uk-text-uppercase">{{ resumo }}</h1>

    <div uk-grid>
      <div class="uk-width-1-2">
        <label for="ritm" class="required">RITM</label>
        <input id="ritm" type="text" class="uk-input" required v-model="ritm" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-2">
        <label for="software" class="required">Software</label>
        <input id="software" type="text" class="uk-input" required v-model="software" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="fabricante" class="required">Fabricante</label>
        <input id="fabricante" type="text" class="uk-input" required v-model="fabricante" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="site-fabricante" class="required">Site do fabricante</label>
        <input id="site-fabricante" type="text" class="uk-input" required v-model="siteFabricante" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3">
        <label for="sistema-operacional" class="required">Sistema Operacional</label>
        <select id="sistema-operacional" class="uk-select" v-model="sistemaOperacional" @change="updateDetalhes">
          <option>Windows</option>
          <option>Mac</option>
          <option>Linux</option>
        </select>
      </div>

      <div class="uk-width-1-1">
        <label for="links">Links</label>
        <textarea id="links" class="uk-textarea" rows="4" style="height: auto" v-model="links" @change="updateDetalhes"></textarea>
      </div>

      <div class="uk-width-1-3">
        <label for="apontamentos" class="uk-form-label required">Apontamentos</label>
        <select id="apontamentos" class="uk-select" v-model="apontamentos" @change="updateDetalhes">
          <option>Não</option>
          <option>Sim</option>
        </select>
      </div>

      <div class="uk-width-1-3 dn depende-apontamentos">
        <label for="suporte">Suporte</label>
        <input id="suporte" type="text" class="uk-input" v-model="suporte" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-3 dn depende-apontamentos">
        <label for="politica-privacidade">Política de privacidade</label>
        <input id="politica-privacidade" type="text" class="uk-input" v-model="politicaPrivacidade" @input="updateDetalhes" />
      </div>

      <div class="uk-width-1-1 dn depende-apontamentos">
        <label for="outros">Outros</label>
        <textarea id="outros" class="uk-textarea" rows="4" style="height: auto" v-model="outros"></textarea>
      </div>
    </div>

    <log-buttons />
  </div>
</template>

<script>
import Fraseologia from '~/plugins/fraseologia.js';
import LogButtons from '~/components/log-buttons';

export default {
  layout: 'fraseologia',
  head() {
    return {
      titleTemplate: `%s - ${this.resumo}`,
    };
  },
  components: {
    LogButtons,
  },
  data() {
    return {
      resumo: 'EULA',
      status: 'Em andamento',
      detalhes: '',
      // ---
      ritm: '',
      fabricante: '',
      software: '',
      siteFabricante: '',
      sistemaOperacional: 'Windows',
      links: '',
      apontamentos: 'Não',
      apontamentosTitulo: '',
      suporte: '',
      suporteConteudo: '',
      politicaPrivacidade: '',
      politicaPrivacidadeConteudo: '',
      outros: '',
      outrosConteudo: '',
    };
  },
  mounted() {
    Fraseologia.focusFirst();
    Fraseologia.selectForm();
    Fraseologia.onPasteFocusNext();

    this.$store.commit('updateResumo', this.resumo);
    this.$store.commit('updateStatus', this.status);
  },
  methods: {
    updateDetalhes() {
      this.checkApontamentos();

      if (this.apontamentos === 'Sim') {
        this.apontamentosTitulo = '\n\nApontamentos:'
      }

      if (this.suporte) {
        this.suporteConteudo = `\nSuporte: ${this.suporte}`
      }

      if (this.politicaPrivacidade) {
        this.politicaPrivacidadeConteudo = `\nPolitica de privacidade: ${this.politicaPrivacidade}`
      }

      if (this.outros) {
        this.outrosConteudo = `\nOutros: ${this.outros}`
      }

      this.detalhes = `RITM: ${this.ritm}
Fabricante: ${this.fabricante}
Software: ${this.software} - ${this.ritm}
Site do fabricante: ${this.siteFabricante}
Sistema Operacional: ${this.sistemaOperacional}
Links: ${this.links}${this.apontamentosTitulo}${this.suporteConteudo}${this.politicaPrivacidadeConteudo}${this.outrosConteudo}
Análise de EULA concluída.`;

      this.$store.commit('updateDetalhes', this.detalhes);
    },

    checkApontamentos() {
      let el = document.querySelectorAll('.depende-apontamentos');

      if (this.apontamentos === 'Sim') {
        for (let i = 0; i < el.length; i++) {
          el[i].classList.remove('dn');
        }
      } else {
        for (let i = 0; i < el.length; i++) {
          el[i].classList.add('dn');
        }
      }
    }
  },
};
</script>