<template>
  <nav class="uk-navbar-container uk-margin-bottom">
    <div class="uk-container uk-container-small">
      <nav class="uk-navbar" uk-navbar>
        <AppLogo />
        <MenuLicenca />
      </nav>
    </div>
  </nav>
</template>

<script>
import AppLogo from '~/components/app-logo.vue';
import MenuLicenca from '~/components/licenca-menu.vue';

export default {
  components: {
    AppLogo,
    MenuLicenca,
  },
};
</script>